import { useState } from 'react';
import { ArrowLeft, MapPin, Bell, AlertTriangle, Waves, Flame, CloudRain, Zap } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { BottomNavigation } from './BottomNavigation';
import alertsImage from 'figma:asset/a1c8f416363d9c7d7307310557a2053a2727e6a6.png';

interface DisasterAlertsScreenProps {
  onNavigate: (screen: string) => void;
}

interface Alert {
  id: number;
  type: 'earthquake' | 'tsunami' | 'wildfire' | 'flood' | 'storm';
  severity: 'URGENT' | 'WARNING' | 'DANGER' | 'ADVISORY';
  title: string;
  description: string;
  time: string;
  distance?: string;
  icon: React.ReactNode;
  color: string;
  bgColor: string;
}

export function DisasterAlertsScreen({ onNavigate }: DisasterAlertsScreenProps) {
  const [activeFilter, setActiveFilter] = useState('All Alerts');

  const filters = ['All Alerts', 'Nearby', 'High Priority', 'Earthquake'];

  const alerts: Alert[] = [
    {
      id: 1,
      type: 'earthquake',
      severity: 'URGENT',
      title: 'Earthquake',
      description: 'Magnitude 6.2 earthquake detected near San Francisco Bay Area. Expect aftershocks.',
      time: '2 min ago',
      distance: '12 miles from your location',
      icon: <AlertTriangle className="w-6 h-6" />,
      color: 'text-red-600',
      bgColor: 'bg-red-50'
    },
    {
      id: 2,
      type: 'tsunami',
      severity: 'WARNING',
      title: 'Tsunami Warning',
      description: 'Potential tsunami following the earthquake. Coastal areas should be on high alert.',
      time: '15 min ago',
      distance: 'Pacific Coast',
      icon: <Waves className="w-6 h-6" />,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50'
    },
    {
      id: 3,
      type: 'wildfire',
      severity: 'DANGER',
      title: 'Wildfire',
      description: 'Rapidly spreading wildfire in Sonoma County. Air quality affected in surrounding areas.',
      time: '1 hour ago',
      distance: '23 miles from your location',
      icon: <Flame className="w-6 h-6" />,
      color: 'text-red-600',
      bgColor: 'bg-red-50'
    },
    {
      id: 4,
      type: 'flood',
      severity: 'ADVISORY',
      title: 'Flood Warning',
      description: 'Heavy rainfall causing flooding in low-lying areas. Avoid flooded roads.',
      time: '3 hours ago',
      distance: 'Bay Area',
      icon: <CloudRain className="w-6 h-6" />,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      id: 5,
      type: 'storm',
      severity: 'ADVISORY',
      title: 'Severe Thunderstorm',
      description: 'Thunderstorm with potential for lightning strikes and strong winds expected this evening.',
      time: 'Yesterday',
      distance: 'Bay Area',
      icon: <Zap className="w-6 h-6" />,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    }
  ];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'URGENT':
        return 'bg-red-500 text-white';
      case 'WARNING':
        return 'bg-orange-500 text-white';
      case 'DANGER':
        return 'bg-red-500 text-white';
      case 'ADVISORY':
        return 'bg-blue-500 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  const filteredAlerts = alerts.filter(alert => {
    if (activeFilter === 'All Alerts') return true;
    if (activeFilter === 'Nearby') return alert.distance?.includes('miles');
    if (activeFilter === 'High Priority') return alert.severity === 'URGENT' || alert.severity === 'DANGER';
    if (activeFilter === 'Earthquake') return alert.type === 'earthquake';
    return true;
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-blue-500 px-4 py-3 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onNavigate('home')}
              className="text-white hover:bg-white/20 p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-lg font-medium">Disaster Alerts</h1>
              <p className="text-blue-100 text-sm">Stay informed about emergencies in your area</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="px-4 py-4 bg-white">
        <div className="flex gap-2 overflow-x-auto">
          {filters.map((filter) => (
            <Button
              key={filter}
              variant={activeFilter === filter ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveFilter(filter)}
              className={`whitespace-nowrap ${
                activeFilter === filter 
                  ? 'bg-blue-500 text-white hover:bg-blue-600' 
                  : 'bg-white text-gray-600 border-gray-300 hover:bg-gray-50'
              }`}
            >
              {filter}
            </Button>
          ))}
        </div>
      </div>

      {/* Emergency Alert Banner */}
      <div className="mx-4 mb-4">
        <div className="bg-red-500 text-white p-4 rounded-lg flex items-start gap-3">
          <AlertTriangle className="w-6 h-6 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <h3 className="font-semibold mb-1">EMERGENCY ALERT</h3>
            <p className="text-sm text-red-100">
              Multiple active alerts in your area. Stay vigilant.
            </p>
          </div>
        </div>
      </div>

      {/* Alerts List */}
      <div className="px-4 pb-24 space-y-4">
        {filteredAlerts.map((alert) => (
          <div key={alert.id} className="bg-white rounded-lg border border-gray-200 overflow-hidden">
            <div className="p-4">
              <div className="flex items-start gap-3">
                {/* Alert Icon */}
                <div className={`p-3 rounded-full ${alert.bgColor} flex-shrink-0`}>
                  <div className={alert.color}>
                    {alert.icon}
                  </div>
                </div>

                {/* Alert Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Badge className={`text-xs px-2 py-1 ${getSeverityColor(alert.severity)}`}>
                        {alert.severity}
                      </Badge>
                      <span className="text-xs text-gray-500">{alert.time}</span>
                    </div>
                  </div>

                  <h3 className="font-semibold text-gray-900 mb-1">{alert.title}</h3>
                  <p className="text-sm text-gray-600 mb-3">{alert.description}</p>

                  {alert.distance && (
                    <p className="text-xs text-gray-500 mb-3 flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      {alert.distance}
                    </p>
                  )}

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="text-blue-600 border-blue-200 hover:bg-blue-50"
                    >
                      Read More →
                    </Button>
                    {(alert.severity === 'URGENT' || alert.severity === 'DANGER') && (
                      <Button 
                        size="sm"
                        className="bg-red-500 hover:bg-red-600 text-white"
                      >
                        Safety Tips
                      </Button>
                    )}
                    {alert.severity === 'WARNING' && (
                      <Button 
                        size="sm"
                        className="bg-orange-500 hover:bg-orange-600 text-white"
                      >
                        Evacuation Map
                      </Button>
                    )}
                    {alert.severity === 'ADVISORY' && (
                      <Button 
                        size="sm"
                        className="bg-blue-500 hover:bg-blue-600 text-white"
                      >
                        Safety Tips
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}

        {filteredAlerts.length === 0 && (
          <div className="text-center py-8">
            <Bell className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No alerts found</h3>
            <p className="text-gray-500">No alerts match your current filter selection.</p>
          </div>
        )}
      </div>

      <BottomNavigation 
        activeTab="alerts" 
        onTabChange={(tab) => {
          const screenMap: { [key: string]: string } = {
            'home': 'home',
            'map': 'parks',
            'alerts': 'alerts',
            'forecast': 'forecast',
            'settings': 'settings'
          };
          if (screenMap[tab]) {
            onNavigate(screenMap[tab]);
          }
        }} 
      />
    </div>
  );
}