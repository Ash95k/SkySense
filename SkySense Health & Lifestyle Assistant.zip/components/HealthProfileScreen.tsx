import { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Checkbox } from './ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { User, Heart, Activity, Sun, Sparkles, Flower, Pill, Plus, Trash2, Clock, ChevronDown, ChevronUp } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface Medication {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  times: string[];
  condition: string;
  isActive: boolean;
  notes?: string;
}

interface UserProfile {
  hasAsthma: boolean;
  hasDustAllergy: boolean;
  hasPollenAllergy: boolean;
  hasHeartCondition: boolean;
  hasUVSensitivity: boolean;
  gender: string;
  ageGroup: string;
  medications: Medication[];
}

interface HealthProfileScreenProps {
  initialProfile: UserProfile;
  onSave: (profile: UserProfile) => void;
}

export function HealthProfileScreen({ initialProfile, onSave }: HealthProfileScreenProps) {
  const [profile, setProfile] = useState<UserProfile>({
    ...initialProfile,
    medications: initialProfile.medications || []
  });
  const [showMedicationsSection, setShowMedicationsSection] = useState(false);
  const [isAddingMedication, setIsAddingMedication] = useState(false);
  const [newMedication, setNewMedication] = useState<Partial<Medication>>({
    name: '',
    dosage: '',
    frequency: 'daily',
    times: [],
    condition: '',
    isActive: true,
    notes: ''
  });

  const handleConditionChange = (condition: keyof UserProfile, checked: boolean) => {
    setProfile(prev => ({
      ...prev,
      [condition]: checked
    }));
    
    // Provide immediate feedback to user
    const conditionNames: { [key: string]: string } = {
      hasAsthma: 'Asthma',
      hasDustAllergy: 'Dust Allergy',
      hasPollenAllergy: 'Pollen Allergy', 
      hasHeartCondition: 'Heart Condition',
      hasUVSensitivity: 'UV Sensitivity'
    };
    
    const conditionName = conditionNames[condition] || condition;
    if (checked) {
      toast.success(`${conditionName} added to your health profile`);
    } else {
      toast.success(`${conditionName} removed from your health profile`);
    }
  };

  const handleSelectChange = (field: keyof UserProfile, value: string) => {
    setProfile(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const getConditionOptions = () => {
    const conditions = [];
    if (profile.hasAsthma) conditions.push('Asthma');
    if (profile.hasDustAllergy) conditions.push('Dust Allergy');
    if (profile.hasPollenAllergy) conditions.push('Pollen Allergy');
    if (profile.hasHeartCondition) conditions.push('Heart Condition');
    if (profile.hasUVSensitivity) conditions.push('UV Sensitivity');
    conditions.push('Other');
    return conditions;
  };

  const getFrequencyTimes = (frequency: string): string[] => {
    switch (frequency) {
      case 'once-daily':
        return ['08:00'];
      case 'twice-daily':
        return ['08:00', '20:00'];
      case 'three-times':
        return ['08:00', '14:00', '20:00'];
      case 'four-times':
        return ['06:00', '12:00', '18:00', '22:00'];
      case 'as-needed':
        return [];
      default:
        return ['08:00'];
    }
  };

  const handleAddMedication = () => {
    if (!newMedication.name || !newMedication.dosage) {
      toast.error('Please fill in medication name and dosage');
      return;
    }

    const medication: Medication = {
      id: `med_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      name: newMedication.name!,
      dosage: newMedication.dosage!,
      frequency: newMedication.frequency || 'daily',
      times: getFrequencyTimes(newMedication.frequency || 'daily'),
      condition: newMedication.condition || 'General',
      isActive: true,
      notes: newMedication.notes || ''
    };

    setProfile(prev => ({
      ...prev,
      medications: [...prev.medications, medication]
    }));

    // Reset form
    setNewMedication({
      name: '',
      dosage: '',
      frequency: 'daily',
      times: [],
      condition: '',
      isActive: true,
      notes: ''
    });
    setIsAddingMedication(false);
    
    toast.success(`${medication.name} added to your medications`);
  };

  const handleRemoveMedication = (medicationId: string) => {
    const medication = profile.medications.find(m => m.id === medicationId);
    setProfile(prev => ({
      ...prev,
      medications: prev.medications.filter(m => m.id !== medicationId)
    }));
    
    if (medication) {
      toast.success(`${medication.name} removed from your medications`);
    }
  };

  const handleToggleMedication = (medicationId: string) => {
    setProfile(prev => ({
      ...prev,
      medications: prev.medications.map(m => 
        m.id === medicationId ? { ...m, isActive: !m.isActive } : m
      )
    }));
  };

  const handleSave = () => {
    // Show saving feedback
    toast.success('Health profile saved successfully!');
    onSave(profile);
  };

  const isFormValid = profile.gender && profile.ageGroup;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-blue-500 px-4 py-3 text-white">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
            <User className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-lg font-medium">Health Profile</h1>
        </div>
        <p className="text-sm text-blue-100">
          Help us customize alerts and suggestions for you
        </p>
      </div>

      <div className="p-4 pb-20 space-y-6">
        {/* Health Conditions */}
        <Card className="p-4">
          <h3 className="font-medium text-foreground mb-4">Health Conditions</h3>
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <Checkbox
                id="asthma"
                checked={profile.hasAsthma}
                onCheckedChange={(checked) => handleConditionChange('hasAsthma', checked as boolean)}
              />
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-blue-500" />
                <Label htmlFor="asthma" className="text-foreground">Asthma</Label>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <Checkbox
                id="dustAllergy"
                checked={profile.hasDustAllergy}
                onCheckedChange={(checked) => handleConditionChange('hasDustAllergy', checked as boolean)}
              />
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-orange-500" />
                <Label htmlFor="dustAllergy" className="text-foreground">Dust Allergy</Label>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <Checkbox
                id="pollenAllergy"
                checked={profile.hasPollenAllergy}
                onCheckedChange={(checked) => handleConditionChange('hasPollenAllergy', checked as boolean)}
              />
              <div className="flex items-center gap-2">
                <Flower className="w-4 h-4 text-pink-500" />
                <Label htmlFor="pollenAllergy" className="text-foreground">Pollen Allergy</Label>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <Checkbox
                id="heartCondition"
                checked={profile.hasHeartCondition}
                onCheckedChange={(checked) => handleConditionChange('hasHeartCondition', checked as boolean)}
              />
              <div className="flex items-center gap-2">
                <Heart className="w-4 h-4 text-red-500" />
                <Label htmlFor="heartCondition" className="text-foreground">Heart Condition</Label>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <Checkbox
                id="uvSensitivity"
                checked={profile.hasUVSensitivity}
                onCheckedChange={(checked) => handleConditionChange('hasUVSensitivity', checked as boolean)}
              />
              <div className="flex items-center gap-2">
                <Sun className="w-4 h-4 text-yellow-500" />
                <Label htmlFor="uvSensitivity" className="text-foreground">UV Sensitivity</Label>
              </div>
            </div>
          </div>
        </Card>

        {/* Personal Information */}
        <Card className="p-4">
          <h3 className="font-medium text-foreground mb-4">Personal Information</h3>
          <div className="space-y-4">
            <div>
              <Label htmlFor="gender" className="text-foreground mb-2 block">Gender</Label>
              <Select value={profile.gender} onValueChange={(value) => handleSelectChange('gender', value)}>
                <SelectTrigger className="min-h-11">
                  <SelectValue placeholder="Select your gender" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="male">Male</SelectItem>
                  <SelectItem value="female">Female</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                  <SelectItem value="prefer-not-to-say">Prefer not to say</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="ageGroup" className="text-foreground mb-2 block">Age Group</Label>
              <Select value={profile.ageGroup} onValueChange={(value) => handleSelectChange('ageGroup', value)}>
                <SelectTrigger className="min-h-11">
                  <SelectValue placeholder="Select your age group" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="under-18">Under 18</SelectItem>
                  <SelectItem value="18-25">18-25</SelectItem>
                  <SelectItem value="26-35">26-35</SelectItem>
                  <SelectItem value="36-50">36-50</SelectItem>
                  <SelectItem value="51-65">51-65</SelectItem>
                  <SelectItem value="over-65">Over 65</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </Card>

        {/* Medications Section (Optional) */}
        <Card className="p-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Pill className="w-5 h-5 text-purple-500" />
              <h3 className="font-medium text-foreground">Medications</h3>
              <Badge variant="secondary" className="text-xs">Optional</Badge>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowMedicationsSection(!showMedicationsSection)}
              className="min-h-11"
            >
              {showMedicationsSection ? (
                <ChevronUp className="w-4 h-4" />
              ) : (
                <ChevronDown className="w-4 h-4" />
              )}
            </Button>
          </div>

          {showMedicationsSection && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Add medications you're currently taking to receive personalized reminders and health alerts.
              </p>

              {/* Current Medications */}
              {profile.medications.length > 0 && (
                <div className="space-y-3">
                  <h4 className="text-sm font-medium text-foreground">Current Medications</h4>
                  {profile.medications.map((medication) => (
                    <div key={medication.id} className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h5 className="font-medium text-foreground">{medication.name}</h5>
                            <Badge 
                              variant={medication.isActive ? "default" : "secondary"}
                              className="text-xs"
                            >
                              {medication.isActive ? 'Active' : 'Paused'}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-1">
                            {medication.dosage} • {medication.frequency.replace('-', ' ')}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            For: {medication.condition}
                          </p>
                          {medication.times.length > 0 && (
                            <div className="flex items-center gap-1 mt-2">
                              <Clock className="w-3 h-3 text-muted-foreground" />
                              <span className="text-xs text-muted-foreground">
                                {medication.times.join(', ')}
                              </span>
                            </div>
                          )}
                        </div>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleToggleMedication(medication.id)}
                            className="p-2 min-h-11"
                          >
                            {medication.isActive ? '⏸️' : '▶️'}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleRemoveMedication(medication.id)}
                            className="p-2 text-red-600 hover:text-red-700 min-h-11"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Add New Medication */}
              {!isAddingMedication ? (
                <Button
                  variant="outline"
                  onClick={() => setIsAddingMedication(true)}
                  className="w-full border-dashed min-h-11"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Medication
                </Button>
              ) : (
                <div className="bg-blue-50 dark:bg-blue-950/20 rounded-lg p-4 space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label className="text-sm font-medium text-foreground mb-1 block">Medication Name</Label>
                      <Input
                        placeholder="e.g., Ibuprofen"
                        value={newMedication.name || ''}
                        onChange={(e) => setNewMedication(prev => ({ ...prev, name: e.target.value }))}
                        className="min-h-11"
                      />
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-foreground mb-1 block">Dosage</Label>
                      <Input
                        placeholder="e.g., 200mg"
                        value={newMedication.dosage || ''}
                        onChange={(e) => setNewMedication(prev => ({ ...prev, dosage: e.target.value }))}
                        className="min-h-11"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label className="text-sm font-medium text-foreground mb-1 block">Frequency</Label>
                      <Select 
                        value={newMedication.frequency || 'once-daily'} 
                        onValueChange={(value) => setNewMedication(prev => ({ ...prev, frequency: value }))}
                      >
                        <SelectTrigger className="min-h-11">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="once-daily">Once daily</SelectItem>
                          <SelectItem value="twice-daily">Twice daily</SelectItem>
                          <SelectItem value="three-times">Three times daily</SelectItem>
                          <SelectItem value="four-times">Four times daily</SelectItem>
                          <SelectItem value="as-needed">As needed</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-foreground mb-1 block">Condition</Label>
                      <Select 
                        value={newMedication.condition || ''} 
                        onValueChange={(value) => setNewMedication(prev => ({ ...prev, condition: value }))}
                      >
                        <SelectTrigger className="min-h-11">
                          <SelectValue placeholder="Select condition" />
                        </SelectTrigger>
                        <SelectContent>
                          {getConditionOptions().map(condition => (
                            <SelectItem key={condition} value={condition}>{condition}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-foreground mb-1 block">Notes (Optional)</Label>
                    <Input
                      placeholder="e.g., Take with food"
                      value={newMedication.notes || ''}
                      onChange={(e) => setNewMedication(prev => ({ ...prev, notes: e.target.value }))}
                      className="min-h-11"
                    />
                  </div>

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setIsAddingMedication(false);
                        setNewMedication({
                          name: '',
                          dosage: '',
                          frequency: 'daily',
                          times: [],
                          condition: '',
                          isActive: true,
                          notes: ''
                        });
                      }}
                      className="flex-1 min-h-11"
                    >
                      Cancel
                    </Button>
                    <Button
                      onClick={handleAddMedication}
                      className="flex-1 min-h-11"
                    >
                      Add Medication
                    </Button>
                  </div>
                </div>
              )}

              {/* Medication Reminders Notice */}
              {profile.medications.length > 0 && (
                <div className="bg-purple-50 dark:bg-purple-950/20 rounded-lg p-3">
                  <p className="text-sm text-purple-800 dark:text-purple-200 flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    Medication reminders can be enabled in Settings to help you stay on track.
                  </p>
                </div>
              )}
            </div>
          )}
        </Card>

        {/* Privacy Notice */}
        <Card className="p-4 bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800">
          <p className="text-sm text-blue-800 dark:text-blue-200">
            🔐 Your health information is stored locally on your device and used only to personalize your experience. We never share this data with third parties.
          </p>
        </Card>
      </div>

      {/* Footer */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-background border-t border-border">
        <div className="max-w-sm mx-auto">
          <Button 
            onClick={handleSave}
            disabled={!isFormValid}
            className="w-full min-h-11"
            size="lg"
          >
            Save & Continue
          </Button>
        </div>
      </div>
    </div>
  );
}