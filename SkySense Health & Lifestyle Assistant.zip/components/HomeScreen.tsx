import { useEffect } from 'react';
import { WeatherCard } from './WeatherCard';
import { AirQualityCard } from './AirQualityCard';
import { HealthAdvisoryCard } from './HealthAdvisoryCard';
import { SkinCareCard } from './SkinCareCard';
import { RecommendationsSection } from './RecommendationsSection';
import { BottomNavigation } from './BottomNavigation';
import { Header } from './Header';
import { VoiceAssistant } from './VoiceAssistant';
import { useSkySenseData } from '../utils/hooks/useSkySenseData';
import { Card } from './ui/card';
import { Loader2 } from 'lucide-react';

interface UserProfile {
  hasAsthma: boolean;
  hasDustAllergy: boolean;
  hasPollenAllergy: boolean;
  hasHeartCondition: boolean;
  hasUVSensitivity: boolean;
  gender: string;
  ageGroup: string;
}

interface HomeScreenProps {
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  onNavigate: (screen: string) => void;
  userProfile: UserProfile;
}

export function HomeScreen({ isDarkMode, onToggleDarkMode, onNavigate, userProfile }: HomeScreenProps) {
  // Get userId from localStorage for demo purposes
  const userId = localStorage.getItem('skysense_profile_id') || 'demo_user';
  
  // Use the SkySense data hook
  const {
    weather,
    airQuality,
    loading,
    error,
    refreshWeather,
    refreshAirQuality,
    recordEcoAction
  } = useSkySenseData(userId);

  const handleTabChange = (tab: string) => {
    const screenMap: { [key: string]: string } = {
      home: 'home',
      map: 'parks',
      alerts: 'alerts',
      forecast: 'forecast',
      settings: 'settings'
    };
    
    if (screenMap[tab]) {
      onNavigate(screenMap[tab]);
    }
  };

  // Record page view for analytics
  useEffect(() => {
    recordEcoAction('view_dashboard', 'engagement', 1).catch(console.error);
  }, [recordEcoAction]);

  return (
    <>
      <Header 
        isDarkMode={isDarkMode} 
        onToggleDarkMode={onToggleDarkMode}
        onNavigate={onNavigate}
      />
      
      <main className="px-4 pb-20 pt-4 space-y-4">
        {loading ? (
          <Card className="p-6 text-center">
            <Loader2 className="w-8 h-8 animate-spin mx-auto mb-2 text-blue-600" />
            <p className="text-muted-foreground">Loading your personalized data...</p>
          </Card>
        ) : error ? (
          <Card className="p-6 text-center border-red-200 bg-red-50 dark:bg-red-950/20">
            <p className="text-red-700 dark:text-red-300 mb-2">Failed to load data</p>
            <p className="text-sm text-red-600 dark:text-red-400">{error}</p>
            <button 
              onClick={() => {
                refreshWeather();
                refreshAirQuality();
              }}
              className="mt-3 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
            >
              Retry
            </button>
          </Card>
        ) : (
          <>
            <WeatherCard weatherData={weather} />
            <AirQualityCard aqiData={airQuality} />
            <HealthAdvisoryCard userProfile={userProfile} weatherData={weather} aqiData={airQuality} />
            <SkinCareCard weatherData={weather} />
            <RecommendationsSection userProfile={userProfile} weatherData={weather} aqiData={airQuality} />
          </>
        )}
      </main>

      <VoiceAssistant />
      <BottomNavigation activeTab="home" onTabChange={handleTabChange} />
    </>
  );
}