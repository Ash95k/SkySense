import { useState } from 'react';
import { ArrowLeft, MapPin, Camera, Send, MessageSquare, ThumbsUp, AlertTriangle } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { BottomNavigation } from './BottomNavigation';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface CommunityReportsScreenProps {
  onNavigate: (screen: string) => void;
}

interface Report {
  id: string;
  type: 'air-quality' | 'visual' | 'smell' | 'weather';
  title: string;
  description: string;
  location: string;
  timestamp: string;
  severity: 'good' | 'moderate' | 'poor';
  verified: boolean;
  likes: number;
  user: string;
  image?: string;
}

export function CommunityReportsScreen({ onNavigate }: CommunityReportsScreenProps) {
  const [showReportForm, setShowReportForm] = useState(false);
  const [reportType, setReportType] = useState<'air-quality' | 'visual' | 'smell' | 'weather'>('air-quality');
  const [reportTitle, setReportTitle] = useState('');
  const [reportDescription, setReportDescription] = useState('');

  const mockReports: Report[] = [
    {
      id: '1',
      type: 'smell',
      title: 'Strong chemical smell',
      description: 'Heavy chemical odor near the construction site. Caused headaches.',
      location: 'Central Park West',
      timestamp: '15 min ago',
      severity: 'poor',
      verified: true,
      likes: 8,
      user: 'Sarah M.',
      image: 'https://images.unsplash.com/photo-1572783133627-9bf6ed52c60b?w=400&h=300&fit=crop'
    },
    {
      id: '2',
      type: 'visual',
      title: 'Clear skies spotted',
      description: 'Visibility much better today, can see the city skyline clearly!',
      location: 'Brooklyn Bridge',
      timestamp: '1 hour ago',
      severity: 'good',
      verified: false,
      likes: 15,
      user: 'Mike R.',
      image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop'
    },
    {
      id: '3',
      type: 'air-quality',
      title: 'Dusty conditions',
      description: 'Lots of dust particles visible in sunlight. Wearing mask recommended.',
      location: 'Times Square',
      timestamp: '2 hours ago',
      severity: 'moderate',
      verified: true,
      likes: 12,
      user: 'Jennifer L.'
    }
  ];

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'smell': return '👃';
      case 'visual': return '👁️';
      case 'air-quality': return '💨';
      case 'weather': return '🌤️';
      default: return '📍';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'good': return 'bg-green-100 text-green-800 border-green-200';
      case 'moderate': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'poor': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const handleSubmitReport = () => {
    if (reportTitle && reportDescription) {
      // Here you would submit to your backend
      console.log('Submitting report:', { reportType, reportTitle, reportDescription });
      setShowReportForm(false);
      setReportTitle('');
      setReportDescription('');
    }
  };

  if (showReportForm) {
    return (
      <div className="min-h-screen bg-background">
        {/* Header */}
        <div className="bg-blue-500 px-4 py-3 text-white">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowReportForm(false)}
              className="text-white hover:bg-white/20 p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-lg font-medium">Report Conditions</h1>
          </div>
        </div>

        <div className="p-4 pb-20 space-y-4">
          {/* Report Type Selection */}
          <Card className="p-4">
            <h3 className="font-medium text-foreground mb-3">What are you reporting?</h3>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'air-quality', label: 'Air Quality', icon: '💨' },
                { id: 'smell', label: 'Odor/Smell', icon: '👃' },
                { id: 'visual', label: 'Visibility', icon: '👁️' },
                { id: 'weather', label: 'Weather', icon: '🌤️' }
              ].map((type) => (
                <Button
                  key={type.id}
                  variant={reportType === type.id ? 'default' : 'outline'}
                  onClick={() => setReportType(type.id as any)}
                  className={`p-3 h-auto ${reportType === type.id ? 'bg-blue-500 text-white' : ''}`}
                >
                  <div className="text-center">
                    <div className="text-lg mb-1">{type.icon}</div>
                    <div className="text-xs">{type.label}</div>
                  </div>
                </Button>
              ))}
            </div>
          </Card>

          {/* Report Details */}
          <Card className="p-4">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Title</label>
                <Input
                  placeholder="Brief description of what you observed"
                  value={reportTitle}
                  onChange={(e) => setReportTitle(e.target.value)}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Details</label>
                <Textarea
                  placeholder="Describe the conditions you're experiencing..."
                  value={reportDescription}
                  onChange={(e) => setReportDescription(e.target.value)}
                  rows={4}
                />
              </div>

              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">Current location will be added automatically</span>
              </div>
            </div>
          </Card>

          {/* Optional Photo */}
          <Card className="p-4">
            <h4 className="font-medium text-foreground mb-3">Add Photo (Optional)</h4>
            <Button variant="outline" className="w-full h-20 border-dashed">
              <div className="text-center">
                <Camera className="w-6 h-6 mx-auto mb-1 text-muted-foreground" />
                <div className="text-sm text-muted-foreground">Tap to add photo</div>
              </div>
            </Button>
          </Card>

          {/* Submit Button */}
          <Button 
            onClick={handleSubmitReport}
            disabled={!reportTitle || !reportDescription}
            className="w-full bg-blue-500 hover:bg-blue-600 text-white"
          >
            <Send className="w-4 h-4 mr-2" />
            Submit Report
          </Button>
        </div>

        <BottomNavigation 
          activeTab="map" 
          onTabChange={(tab) => {
            const screenMap: { [key: string]: string } = {
              'home': 'home',
              'map': 'parks',
              'alerts': 'alerts',
              'forecast': 'forecast',
              'settings': 'settings'
            };
            if (screenMap[tab]) {
              onNavigate(screenMap[tab]);
            }
          }} 
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-blue-500 px-4 py-3 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onNavigate('home')}
              className="text-white hover:bg-white/20 p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-lg font-medium">Community Reports</h1>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowReportForm(true)}
            className="text-white hover:bg-white/20 px-3 py-2"
          >
            <MessageSquare className="w-4 h-4 mr-2" />
            Report
          </Button>
        </div>
      </div>

      {/* Info Banner */}
      <div className="px-4 py-3 bg-blue-50 dark:bg-blue-950/20 border-b border-blue-200 dark:border-blue-800">
        <div className="flex items-start gap-3">
          <div className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
            <span className="text-white text-xs">💡</span>
          </div>
          <p className="text-sm text-blue-800 dark:text-blue-200">
            Help your community by sharing real-time environmental conditions. Your reports help others make informed decisions.
          </p>
        </div>
      </div>

      {/* Reports List */}
      <div className="p-4 pb-20 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-medium text-foreground">Recent Reports</h2>
          <span className="text-sm text-muted-foreground">{mockReports.length} reports</span>
        </div>

        {mockReports.map((report) => (
          <Card key={report.id} className="p-4">
            <div className="flex gap-3">
              {report.image && (
                <div className="w-16 h-16 flex-shrink-0 rounded-lg overflow-hidden">
                  <ImageWithFallback 
                    src={report.image}
                    alt={report.title}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
              
              <div className="flex-1">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{getTypeIcon(report.type)}</span>
                    <h3 className="font-medium text-foreground">{report.title}</h3>
                    {report.verified && (
                      <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center">
                        <span className="text-white text-xs">✓</span>
                      </div>
                    )}
                  </div>
                  <Badge variant="outline" className={getSeverityColor(report.severity)}>
                    {report.severity}
                  </Badge>
                </div>

                <p className="text-sm text-muted-foreground mb-3 leading-relaxed">
                  {report.description}
                </p>

                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-4 text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      {report.location}
                    </span>
                    <span>{report.timestamp}</span>
                    <span>by {report.user}</span>
                  </div>
                  
                  <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">
                    <ThumbsUp className="w-3 h-3 mr-1" />
                    {report.likes}
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        ))}

        {/* Empty State Help */}
        <Card className="p-6 text-center border-dashed">
          <div className="text-4xl mb-3">🌍</div>
          <h3 className="font-medium text-foreground mb-2">Be the First to Report</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Notice something about air quality, visibility, or environmental conditions? Share it with your community!
          </p>
          <Button onClick={() => setShowReportForm(true)} className="bg-blue-500 hover:bg-blue-600 text-white">
            <MessageSquare className="w-4 h-4 mr-2" />
            Create Report
          </Button>
        </Card>
      </div>

      <BottomNavigation 
        activeTab="map" 
        onTabChange={(tab) => {
          const screenMap: { [key: string]: string } = {
            'home': 'home',
            'map': 'parks',
            'alerts': 'alerts',
            'forecast': 'forecast',
            'settings': 'settings'
          };
          if (screenMap[tab]) {
            onNavigate(screenMap[tab]);
          }
        }} 
      />
    </div>
  );
}