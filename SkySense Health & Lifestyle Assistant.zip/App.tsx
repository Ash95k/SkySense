import { useState, useEffect } from 'react';
import { SplashScreen } from './components/SplashScreen';
import { OnboardingFlow } from './components/OnboardingFlow';
import { HealthProfileScreen } from './components/HealthProfileScreen';
import { HomeScreen } from './components/HomeScreen';
import { NearbyParksScreen } from './components/NearbyParksScreen';
import { DisasterAlertsScreen } from './components/DisasterAlertsScreen';
import { WeeklyForecastScreen } from './components/WeeklyForecastScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { NotificationCenter } from './components/NotificationCenter';
import { AQITrendsScreen } from './components/AQITrendsScreen';
import { ProfileScreen } from './components/ProfileScreen';
import { CommunityReportsScreen } from './components/CommunityReportsScreen';
import { EcoScoreScreen } from './components/EcoScoreScreen';
import { BadgesScreen } from './components/BadgesScreen';
import { VoiceAssistant } from './components/VoiceAssistant';
import { api } from './utils/supabase/client';
import { Toaster } from './components/ui/sonner';

type AppScreen = 'splash' | 'onboarding' | 'healthProfile' | 'home' | 'parks' | 'alerts' | 'forecast' | 'settings' | 'notifications' | 'trends' | 'profile' | 'community' | 'eco' | 'badges';

interface Medication {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  times: string[];
  condition: string;
  isActive: boolean;
  notes?: string;
}

interface UserProfile {
  hasAsthma: boolean;
  hasDustAllergy: boolean;
  hasPollenAllergy: boolean;
  hasHeartCondition: boolean;
  hasUVSensitivity: boolean;
  gender: string;
  ageGroup: string;
  medications: Medication[];
}

interface AppSettings {
  darkMode: boolean;
  voiceAssistant: boolean;
  pushNotifications: boolean;
  weatherAlerts: boolean;
  airQualityAlerts: boolean;
  healthReminders: boolean;
  medicationReminders: boolean;
  communityUpdates: boolean;
  locationSharing: boolean;
  autoRefresh: boolean;
}

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('splash');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile>({
    hasAsthma: false,
    hasDustAllergy: false,
    hasPollenAllergy: false,
    hasHeartCondition: false,
    hasUVSensitivity: false,
    gender: '',
    ageGroup: '',
    medications: []
  });
  const [appSettings, setAppSettings] = useState<AppSettings>({
    darkMode: false,
    voiceAssistant: true,
    pushNotifications: true,
    weatherAlerts: true,
    airQualityAlerts: true,
    healthReminders: true,
    medicationReminders: true,
    communityUpdates: false,
    locationSharing: true,
    autoRefresh: true
  });
  const [isInitialized, setIsInitialized] = useState(false);

  // Initialize app settings and dark mode from localStorage and backend
  useEffect(() => {
    const initializeApp = async () => {
      try {
        console.log('Initializing SkySense mobile app...');
        
        // Test backend connection
        try {
          await api.healthCheck();
          console.log('Backend connection successful');
        } catch (healthError) {
          console.warn('Backend health check failed, app will work in offline mode:', healthError);
        }
        
        // Get stored preferences from localStorage
        const storedDarkMode = localStorage.getItem('skysense_dark_mode');
        const storedProfileId = localStorage.getItem('skysense_profile_id');
        const hasSeenOnboarding = localStorage.getItem('skysense_onboarding_complete');

        console.log('Stored preferences:', {
          darkMode: storedDarkMode,
          profileId: storedProfileId ? 'Present' : 'Not found',
          onboardingComplete: hasSeenOnboarding
        });

        // Set initial dark mode
        const initialDarkMode = storedDarkMode === 'true';
        setIsDarkMode(initialDarkMode);
        document.documentElement.classList.toggle('dark', initialDarkMode);

        // Skip splash/onboarding if user has already completed setup
        if (hasSeenOnboarding === 'true' && storedProfileId) {
          console.log('User has completed onboarding, loading existing data...');
          setCurrentScreen('home');
          
          // Load user profile from backend
          try {
            console.log('Loading user profile from backend...');
            const profileResponse = await api.getProfile(storedProfileId);
            if (profileResponse.profile) {
              // Ensure medications array exists for backward compatibility
              const profile = {
                ...profileResponse.profile,
                medications: profileResponse.profile.medications || []
              };
              setUserProfile(profile);
              console.log('User profile loaded successfully:', profile);
            } else {
              console.log('No profile found in backend response');
            }
          } catch (error) {
            console.error('Failed to load user profile from backend:', error);
            console.log('Continuing with default profile...');
          }

          // Load app settings from backend
          try {
            console.log('Loading app settings from backend...');
            const settingsResponse = await api.getUserSettings(storedProfileId);
            if (settingsResponse.settings) {
              const loadedSettings = {
                ...appSettings,
                ...settingsResponse.settings,
                darkMode: initialDarkMode, // Keep localStorage dark mode preference
                medicationReminders: settingsResponse.settings.medicationReminders ?? true // Default to true
              };
              setAppSettings(loadedSettings);
              console.log('App settings loaded successfully:', loadedSettings);
              
              // Update dark mode if different from stored settings
              if (loadedSettings.darkMode !== initialDarkMode) {
                console.log('Updating dark mode based on backend settings');
                setIsDarkMode(loadedSettings.darkMode);
                document.documentElement.classList.toggle('dark', loadedSettings.darkMode);
                localStorage.setItem('skysense_dark_mode', loadedSettings.darkMode.toString());
              }
            } else {
              console.log('No settings found in backend response, using defaults');
            }
          } catch (error) {
            console.error('Failed to load app settings from backend:', error);
            console.log('Continuing with default settings...');
          }
        } else {
          console.log('First time user or incomplete onboarding, showing splash screen');
        }
      } catch (error) {
        console.error('Failed to initialize app:', error);
        console.log('App will continue with default settings');
      } finally {
        console.log('Mobile app initialization complete');
        setIsInitialized(true);
      }
    };

    initializeApp();
  }, []);

  // Set mobile viewport and prevent zoom
  useEffect(() => {
    // Set mobile-optimized viewport
    const viewport = document.querySelector('meta[name=viewport]');
    if (viewport) {
      viewport.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover');
    } else {
      const meta = document.createElement('meta');
      meta.name = 'viewport';
      meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover';
      document.getElementsByTagName('head')[0].appendChild(meta);
    }

    // Add mobile-specific meta tags
    const mobileWebApp = document.querySelector('meta[name=mobile-web-app-capable]');
    if (!mobileWebApp) {
      const meta = document.createElement('meta');
      meta.name = 'mobile-web-app-capable';
      meta.content = 'yes';
      document.getElementsByTagName('head')[0].appendChild(meta);
    }

    const appleWebApp = document.querySelector('meta[name=apple-mobile-web-app-capable]');
    if (!appleWebApp) {
      const meta = document.createElement('meta');
      meta.name = 'apple-mobile-web-app-capable';
      meta.content = 'yes';
      document.getElementsByTagName('head')[0].appendChild(meta);
    }

    const appleStatusBar = document.querySelector('meta[name=apple-mobile-web-app-status-bar-style]');
    if (!appleStatusBar) {
      const meta = document.createElement('meta');
      meta.name = 'apple-mobile-web-app-status-bar-style';
      meta.content = 'default';
      document.getElementsByTagName('head')[0].appendChild(meta);
    }
  }, []);

  // Medication reminder system
  useEffect(() => {
    if (!isInitialized || !appSettings.medicationReminders || userProfile.medications.length === 0) {
      return;
    }

    const checkMedicationReminders = () => {
      const now = new Date();
      const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
      
      userProfile.medications.forEach(medication => {
        if (medication.isActive && medication.times.includes(currentTime)) {
          // Check if we haven't already sent this reminder today
          const reminderKey = `medication_reminder_${medication.id}_${now.toDateString()}_${currentTime}`;
          if (!localStorage.getItem(reminderKey)) {
            // Send notification
            if ('Notification' in window && Notification.permission === 'granted') {
              new Notification(`Time for ${medication.name}`, {
                body: `Take ${medication.dosage} as prescribed for your ${medication.condition}`,
                icon: '/icon-192x192.png',
                tag: `medication-${medication.id}`
              });
            }
            
            // Mark as sent for today
            localStorage.setItem(reminderKey, 'sent');
            
            console.log(`Medication reminder sent for ${medication.name} at ${currentTime}`);
          }
        }
      });
    };

    // Check every minute
    const interval = setInterval(checkMedicationReminders, 60000);
    
    // Check immediately
    checkMedicationReminders();

    return () => clearInterval(interval);
  }, [isInitialized, appSettings.medicationReminders, userProfile.medications]);

  // Request notification permission when medication reminders are enabled
  useEffect(() => {
    if (appSettings.medicationReminders && 'Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission().then(permission => {
        console.log('Notification permission:', permission);
      });
    }
  }, [appSettings.medicationReminders]);

  // Save settings to backend when they change
  useEffect(() => {
    if (!isInitialized) return;

    const saveSettings = async () => {
      const userId = localStorage.getItem('skysense_profile_id');
      if (userId && appSettings) {
        try {
          await api.saveSettings(userId, appSettings);
        } catch (error) {
          console.error('Failed to save settings:', error);
        }
      }
    };

    saveSettings();
  }, [appSettings, isInitialized]);

  const navigateToScreen = (screen: AppScreen) => {
    setCurrentScreen(screen);
    
    // Add haptic feedback for mobile navigation (if supported)
    if ('vibrate' in navigator) {
      navigator.vibrate(10); // 10ms haptic feedback
    }
  };

  const handleProfileSave = async (profile: UserProfile) => {
    setUserProfile(profile);
    
    try {
      console.log('Attempting to save profile:', profile);
      
      // Save profile to backend
      const response = await api.saveProfile(profile);
      console.log('Profile save response:', response);
      
      if (response.success) {
        // Use profileId (for anonymous users) or userId (for authenticated users)
        const profileId = response.profileId || response.userId;
        if (profileId) {
          localStorage.setItem('skysense_profile_id', profileId);
          console.log('Profile ID stored in localStorage:', profileId);
        }
        
        // Mark onboarding as complete
        localStorage.setItem('skysense_onboarding_complete', 'true');
        
        // Show success feedback
        console.log('Profile saved successfully, navigating to home');
        setCurrentScreen('home');
      } else {
        throw new Error('Profile save was not successful');
      }
    } catch (error) {
      console.error('Failed to save profile:', error);
      
      // Generate a local profile ID for offline functionality
      const fallbackProfileId = `local_profile_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      localStorage.setItem('skysense_profile_id', fallbackProfileId);
      localStorage.setItem('skysense_onboarding_complete', 'true');
      
      console.log('Using fallback profile ID:', fallbackProfileId);
      console.log('Profile saved locally, navigating to home despite backend error');
      
      // Still navigate to home for better UX
      setCurrentScreen('home');
    }
  };

  const toggleDarkMode = () => {
    const newDarkMode = !isDarkMode;
    setIsDarkMode(newDarkMode);
    document.documentElement.classList.toggle('dark', newDarkMode);
    
    // Update local storage
    localStorage.setItem('skysense_dark_mode', newDarkMode.toString());
    
    // Update app settings
    setAppSettings(prev => ({
      ...prev,
      darkMode: newDarkMode
    }));

    // Add haptic feedback for toggle
    if ('vibrate' in navigator) {
      navigator.vibrate(5);
    }
  };

  const updateAppSettings = (newSettings: Partial<AppSettings>) => {
    setAppSettings(prev => ({
      ...prev,
      ...newSettings
    }));
  };

  // Mobile loading screen with proper constraints
  if (!isInitialized) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="max-w-sm mx-auto px-4 text-center">
          <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-muted-foreground text-sm">Loading SkySense...</p>
        </div>
      </div>
    );
  }

  const renderCurrentScreen = () => {
    switch (currentScreen) {
      case 'splash':
        return <SplashScreen onComplete={() => setCurrentScreen('onboarding')} />;
      case 'onboarding':
        return <OnboardingFlow onComplete={() => setCurrentScreen('healthProfile')} />;
      case 'healthProfile':
        return (
          <HealthProfileScreen
            initialProfile={userProfile}
            onSave={handleProfileSave}
          />
        );
      case 'home':
        return (
          <HomeScreen
            isDarkMode={isDarkMode}
            onToggleDarkMode={toggleDarkMode}
            onNavigate={navigateToScreen}
            userProfile={userProfile}
          />
        );
      case 'parks':
        return <NearbyParksScreen onNavigate={navigateToScreen} />;
      case 'alerts':
        return <DisasterAlertsScreen onNavigate={navigateToScreen} />;
      case 'forecast':
        return <WeeklyForecastScreen onNavigate={navigateToScreen} />;
      case 'settings':
        return (
          <SettingsScreen
            isDarkMode={isDarkMode}
            onToggleDarkMode={toggleDarkMode}
            onNavigate={navigateToScreen}
            userProfile={userProfile}
            onEditProfile={() => setCurrentScreen('healthProfile')}
            appSettings={appSettings}
            onUpdateSettings={updateAppSettings}
          />
        );
      case 'notifications':
        return <NotificationCenter onNavigate={navigateToScreen} />;
      case 'trends':
        return <AQITrendsScreen onNavigate={navigateToScreen} />;
      case 'profile':
        return <ProfileScreen 
          onNavigate={navigateToScreen}
          userProfile={userProfile}
          onEditProfile={() => setCurrentScreen('healthProfile')}
        />;
      case 'community':
        return <CommunityReportsScreen onNavigate={navigateToScreen} />;
      case 'eco':
        return <EcoScoreScreen onNavigate={navigateToScreen} />;
      case 'badges':
        return <BadgesScreen onNavigate={navigateToScreen} />;
      default:
        return (
          <HomeScreen
            isDarkMode={isDarkMode}
            onToggleDarkMode={toggleDarkMode}
            onNavigate={navigateToScreen}
            userProfile={userProfile}
          />
        );
    }
  };

  return (
    <div className={`min-h-screen ${isDarkMode ? 'dark' : ''}`}>
      {/* Mobile app container with max width constraint */}
      <div className="max-w-sm mx-auto bg-background min-h-screen relative mobile-app-container">
        {renderCurrentScreen()}
        
        {/* Voice Assistant - Available on all screens except splash and onboarding */}
        {currentScreen !== 'splash' && currentScreen !== 'onboarding' && appSettings.voiceAssistant && (
          <VoiceAssistant />
        )}
        
        {/* Toast notifications - optimized for mobile */}
        <Toaster />
      </div>
    </div>
  );
}