import { createClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from './info';

// Create Supabase client
export const supabase = createClient(
  `https://${projectId}.supabase.co`,
  publicAnonKey
);

// API base URL for our server functions
const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-1ec076f3`;

// API client class
class SkySenseAPI {
  private async request(endpoint: string, options: RequestInit = {}) {
    const url = `${API_BASE}${endpoint}`;
    
    const defaultHeaders = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`,
    };

    try {
      const response = await fetch(url, {
        ...options,
        headers: {
          ...defaultHeaders,
          ...options.headers,
        },
      });

      if (!response.ok) {
        let errorMessage;
        try {
          const errorData = await response.json();
          errorMessage = errorData.error || `HTTP ${response.status}`;
        } catch {
          errorMessage = `HTTP ${response.status}`;
        }
        
        console.error(`API Error - ${endpoint}:`, errorMessage, {
          status: response.status,
          statusText: response.statusText
        });
        
        throw new Error(errorMessage);
      }

      return response.json();
    } catch (error) {
      console.error(`Network Error - ${endpoint}:`, error);
      throw error;
    }
  }

  // User Profile Management
  async saveProfile(profile: any) {
    try {
      console.log('Saving profile:', profile);
      const response = await this.request('/profile', {
        method: 'POST',
        body: JSON.stringify(profile),
      });
      console.log('Profile saved successfully:', response);
      return response;
    } catch (error) {
      console.error('Failed to save profile:', error);
      throw error;
    }
  }

  async getProfile(profileId: string) {
    try {
      console.log('Getting profile:', profileId);
      const response = await this.request(`/profile/${profileId}`);
      console.log('Profile retrieved successfully:', response);
      return response;
    } catch (error) {
      console.error('Failed to get profile:', error);
      // Return empty profile instead of throwing to avoid breaking the app
      return { profile: null };
    }
  }

  // Weather Data
  async getWeather(location: string = 'San Francisco') {
    try {
      return await this.request(`/weather/${encodeURIComponent(location)}`);
    } catch (error) {
      console.error('Failed to get weather data:', error);
      // Return mock data if API fails
      return {
        location,
        current: {
          temperature: 24,
          condition: "Partly Cloudy",
          humidity: 42,
          windSpeed: 8,
          uvIndex: 7,
          precipitation: 0,
          pressure: 1013,
          visibility: 10
        },
        aqi: {
          value: 87,
          category: "Moderate"
        }
      };
    }
  }

  // Air Quality Data
  async getAirQuality(location: string = 'San Francisco') {
    try {
      return await this.request(`/aqi/${encodeURIComponent(location)}`);
    } catch (error) {
      console.error('Failed to get air quality data:', error);
      // Return mock data if API fails
      return {
        location,
        current: {
          aqi: 87,
          category: "Moderate",
          color: "#FFA500"
        }
      };
    }
  }

  // Community Reports
  async submitCommunityReport(report: {
    type: string;
    description: string;
    location?: string;
    severity?: string;
    imageUrl?: string;
  }) {
    try {
      return await this.request('/community/report', {
        method: 'POST',
        body: JSON.stringify(report),
      });
    } catch (error) {
      console.error('Failed to submit community report:', error);
      throw error;
    }
  }

  async getCommunityReports(location: string = 'San Francisco') {
    try {
      return await this.request(`/community/reports/${encodeURIComponent(location)}`);
    } catch (error) {
      console.error('Failed to get community reports:', error);
      return { reports: [] };
    }
  }

  // Eco Score Tracking
  async recordEcoAction(action: {
    userId: string;
    action: string;
    points: number;
    category: string;
  }) {
    try {
      return await this.request('/eco/action', {
        method: 'POST',
        body: JSON.stringify(action),
      });
    } catch (error) {
      console.error('Failed to record eco action:', error);
      throw error;
    }
  }

  async getEcoScore(userId: string) {
    try {
      return await this.request(`/eco/score/${userId}`);
    } catch (error) {
      console.error('Failed to get eco score:', error);
      return { total: 0, recentActions: [], rank: 1 };
    }
  }

  // Badges and Achievements
  async unlockBadge(data: {
    userId: string;
    badgeType: string;
    criteria: any;
  }) {
    try {
      return await this.request('/badges/unlock', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    } catch (error) {
      console.error('Failed to unlock badge:', error);
      throw error;
    }
  }

  async getUserBadges(userId: string) {
    try {
      return await this.request(`/badges/${userId}`);
    } catch (error) {
      console.error('Failed to get user badges:', error);
      return { badges: [] };
    }
  }

  // Notifications
  async createNotification(notification: {
    userId: string;
    title: string;
    message: string;
    type: string;
    priority?: 'low' | 'normal' | 'high';
  }) {
    try {
      return await this.request('/notifications', {
        method: 'POST',
        body: JSON.stringify(notification),
      });
    } catch (error) {
      console.error('Failed to create notification:', error);
      throw error;
    }
  }

  async getUserNotifications(userId: string) {
    try {
      return await this.request(`/notifications/${userId}`);
    } catch (error) {
      console.error('Failed to get notifications:', error);
      return { notifications: [] };
    }
  }

  async markNotificationAsRead(notificationId: string) {
    try {
      return await this.request(`/notifications/${notificationId}/read`, {
        method: 'PUT',
      });
    } catch (error) {
      console.error('Failed to mark notification as read:', error);
      throw error;
    }
  }

  // Parks Data
  async getNearbyParks(location: string = 'San Francisco') {
    try {
      return await this.request(`/parks/${encodeURIComponent(location)}`);
    } catch (error) {
      console.error('Failed to get parks data:', error);
      return { parks: [] };
    }
  }

  // Emergency Alerts
  async getEmergencyAlerts(location: string = 'San Francisco') {
    try {
      return await this.request(`/alerts/${encodeURIComponent(location)}`);
    } catch (error) {
      console.error('Failed to get emergency alerts:', error);
      return { alerts: [] };
    }
  }

  // Settings Management
  async saveSettings(userId: string, settings: any) {
    try {
      console.log('Saving settings for user:', userId, settings);
      const response = await this.request('/settings', {
        method: 'POST',
        body: JSON.stringify({ userId, settings }),
      });
      console.log('Settings saved successfully:', response);
      return response;
    } catch (error) {
      console.error('Failed to save settings:', error);
      throw error;
    }
  }

  async getUserSettings(userId: string) {
    try {
      console.log('Getting settings for user:', userId);
      const response = await this.request(`/settings/${userId}`);
      console.log('Settings retrieved successfully:', response);
      return response;
    } catch (error) {
      console.error('Failed to get user settings:', error);
      // Return default settings if API fails
      return {
        settings: {
          darkMode: false,
          voiceAssistant: true,
          pushNotifications: true,
          weatherAlerts: true,
          airQualityAlerts: true,
          healthReminders: true,
          communityUpdates: false,
          locationSharing: true,
          autoRefresh: true
        }
      };
    }
  }

  // Analytics
  async recordEvent(event: {
    userId: string;
    event: string;
    data?: any;
  }) {
    try {
      return await this.request('/analytics/event', {
        method: 'POST',
        body: JSON.stringify(event),
      });
    } catch (error) {
      console.error('Failed to record analytics event:', error);
      // Don't throw for analytics - it's non-critical
      return { success: false };
    }
  }

  // Health check
  async healthCheck() {
    try {
      const response = await this.request('/health');
      console.log('Health check successful:', response);
      return response;
    } catch (error) {
      console.error('Health check failed:', error);
      throw error;
    }
  }
}

// Export singleton instance
export const api = new SkySenseAPI();

// Export utility functions for common operations
export const weatherUtils = {
  getConditionIcon: (condition: string) => {
    const icons: { [key: string]: string } = {
      'sunny': '☀️',
      'cloudy': '☁️',
      'partly cloudy': '⛅',
      'rainy': '🌧️',
      'stormy': '⛈️',
      'foggy': '🌫️',
      'windy': '💨',
    };
    return icons[condition.toLowerCase()] || '🌤️';
  },
  
  getAQIColor: (aqi: number) => {
    if (aqi <= 50) return '#00E400'; // Green
    if (aqi <= 100) return '#FFFF00'; // Yellow
    if (aqi <= 150) return '#FF7E00'; // Orange
    if (aqi <= 200) return '#FF0000'; // Red
    if (aqi <= 300) return '#8F3F97'; // Purple
    return '#7E0023'; // Maroon
  },
  
  getAQICategory: (aqi: number) => {
    if (aqi <= 50) return 'Good';
    if (aqi <= 100) return 'Moderate';
    if (aqi <= 150) return 'Unhealthy for Sensitive Groups';
    if (aqi <= 200) return 'Unhealthy';
    if (aqi <= 300) return 'Very Unhealthy';
    return 'Hazardous';
  }
};

export const notificationUtils = {
  scheduleHealthReminder: async (userId: string, condition: string) => {
    await api.createNotification({
      userId,
      title: 'Health Reminder',
      message: `Don't forget to take precautions for your ${condition} today based on current air quality.`,
      type: 'health_reminder',
      priority: 'normal'
    });
  },
  
  scheduleWeatherAlert: async (userId: string, alertType: string, message: string) => {
    await api.createNotification({
      userId,
      title: `Weather Alert: ${alertType}`,
      message,
      type: 'weather_alert',
      priority: 'high'
    });
  }
};

export const ecoUtils = {
  calculatePoints: (action: string) => {
    const pointsMap: { [key: string]: number } = {
      'walk_instead_drive': 10,
      'use_public_transport': 15,
      'bike_commute': 20,
      'recycle': 5,
      'use_reusable_bag': 3,
      'conserve_water': 8,
      'use_renewable_energy': 25,
      'plant_tree': 50,
      'report_pollution': 12,
      'share_ride': 18
    };
    return pointsMap[action] || 5;
  },
  
  getBadgeForScore: (score: number) => {
    if (score >= 1000) return { name: 'Eco Champion', level: 'gold' };
    if (score >= 500) return { name: 'Green Guardian', level: 'silver' };
    if (score >= 100) return { name: 'Earth Helper', level: 'bronze' };
    return { name: 'Getting Started', level: 'none' };
  }
};