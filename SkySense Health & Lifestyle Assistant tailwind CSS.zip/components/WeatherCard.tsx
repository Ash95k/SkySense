import { Cloud, Wind, Droplets, Sun } from 'lucide-react';
import { Card } from './ui/card';

export function WeatherCard() {
  return (
    <Card className="p-4 bg-gradient-to-br from-blue-400 to-blue-600 text-white border-0">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-white/90 mb-1">Current Weather</h2>
          <p className="text-white/80 text-sm">New York, NY</p>
        </div>
        <Cloud className="w-8 h-8 text-white/80" />
      </div>
      
      <div className="mb-4">
        <div className="text-4xl font-bold text-white mb-1">24°</div>
        <div className="text-white/80 text-sm">Partly Cloudy</div>
      </div>
      
      <div className="grid grid-cols-3 gap-4 text-sm">
        <div className="flex items-center gap-2">
          <Droplets className="w-4 h-4 text-white/70" />
          <div>
            <div className="text-white/90">Humidity</div>
            <div className="text-white/70">55%</div>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Wind className="w-4 h-4 text-white/70" />
          <div>
            <div className="text-white/90">Wind</div>
            <div className="text-white/70">12 km/h</div>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Sun className="w-4 h-4 text-white/70" />
          <div>
            <div className="text-white/90">UV Index</div>
            <div className="text-white/70">5</div>
          </div>
        </div>
      </div>
    </Card>
  );
}