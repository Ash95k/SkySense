import { useState, useEffect } from 'react';
import { ArrowLeft, Moon, Mic, Bell, User, Globe, Info, Edit, Pill } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { BottomNavigation } from './BottomNavigation';
import { api } from '../utils/supabase/client';
import { toast } from 'sonner@2.0.3';

interface Medication {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  times: string[];
  condition: string;
  isActive: boolean;
  notes?: string;
}

interface UserProfile {
  hasAsthma: boolean;
  hasDustAllergy: boolean;
  hasPollenAllergy: boolean;
  hasHeartCondition: boolean;
  hasUVSensitivity: boolean;
  gender: string;
  ageGroup: string;
  medications: Medication[];
}

interface AppSettings {
  darkMode: boolean;
  voiceAssistant: boolean;
  pushNotifications: boolean;
  weatherAlerts: boolean;
  airQualityAlerts: boolean;
  healthReminders: boolean;
  medicationReminders: boolean;
  communityUpdates: boolean;
  locationSharing: boolean;
  autoRefresh: boolean;
}

interface SettingsScreenProps {
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  onNavigate: (screen: string) => void;
  userProfile: UserProfile;
  onEditProfile: () => void;
  appSettings: AppSettings;
  onUpdateSettings: (settings: Partial<AppSettings>) => void;
}

export function SettingsScreen({ 
  isDarkMode, 
  onToggleDarkMode, 
  onNavigate, 
  userProfile, 
  onEditProfile,
  appSettings,
  onUpdateSettings
}: SettingsScreenProps) {
  const [settings, setSettings] = useState<AppSettings>(appSettings);
  const [loading, setLoading] = useState(false);

  // Get userId from localStorage for demo purposes
  const userId = localStorage.getItem('skysense_profile_id') || 'demo_user';

  // Update local settings when appSettings change
  useEffect(() => {
    setSettings(appSettings);
  }, [appSettings]);

  // Save settings to backend
  const saveSettings = async (newSettings: AppSettings) => {
    setLoading(true);
    try {
      console.log('Attempting to save settings for user:', userId);
      const response = await api.saveSettings(userId, newSettings);
      console.log('Settings save response:', response);
      
      if (response.success) {
        toast.success('Settings saved successfully');
      } else {
        throw new Error('Settings save was not successful');
      }
    } catch (error) {
      console.error('Failed to save settings:', error);
      
      // Save settings locally as fallback
      try {
        const localSettingsKey = `skysense_settings_${userId}`;
        localStorage.setItem(localSettingsKey, JSON.stringify(newSettings));
        console.log('Settings saved locally as fallback');
        toast.success('Settings saved locally');
      } catch (localError) {
        console.error('Failed to save settings locally:', localError);
        toast.error('Failed to save settings');
      }
    } finally {
      setLoading(false);
    }
  };

  // Handle individual setting toggles
  const handleSettingToggle = async (key: keyof AppSettings, value: boolean) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);
    onUpdateSettings({ [key]: value });

    // Handle special cases
    if (key === 'darkMode') {
      onToggleDarkMode();
      newSettings.darkMode = !isDarkMode; // Update based on new dark mode state
    }

    // Save to backend
    await saveSettings(newSettings);

    // Show user feedback for important settings
    if (key === 'pushNotifications') {
      if (value) {
        toast.success('Push notifications enabled');
        // Request notification permission
        if ('Notification' in window && Notification.permission === 'default') {
          Notification.requestPermission();
        }
      } else {
        toast.success('Push notifications disabled');
      }
    }

    if (key === 'voiceAssistant') {
      if (value) {
        toast.success('Voice assistant enabled');
      } else {
        toast.success('Voice assistant disabled');
      }
    }

    if (key === 'medicationReminders') {
      if (value) {
        toast.success('Medication reminders enabled');
        // Request notification permission if not already granted
        if ('Notification' in window && Notification.permission === 'default') {
          Notification.requestPermission().then(permission => {
            if (permission === 'granted') {
              toast.success('You\'ll receive medication reminders at scheduled times');
            }
          });
        }
      } else {
        toast.success('Medication reminders disabled');
      }
    }

    if (key === 'locationSharing') {
      if (value) {
        toast.success('Location sharing enabled for better recommendations');
      } else {
        toast.success('Location sharing disabled');
      }
    }
  };

  // Handle batch settings updates
  const handleNotificationPreset = async (preset: 'all' | 'essential' | 'none') => {
    let updates: Partial<AppSettings> = {};
    
    switch (preset) {
      case 'all':
        updates = {
          pushNotifications: true,
          weatherAlerts: true,
          airQualityAlerts: true,
          healthReminders: true,
          medicationReminders: true,
          communityUpdates: true
        };
        toast.success('All notifications enabled');
        break;
      case 'essential':
        updates = {
          pushNotifications: true,
          weatherAlerts: true,
          airQualityAlerts: true,
          healthReminders: true,
          medicationReminders: true,
          communityUpdates: false
        };
        toast.success('Essential notifications enabled');
        break;
      case 'none':
        updates = {
          pushNotifications: false,
          weatherAlerts: false,
          airQualityAlerts: false,
          healthReminders: false,
          medicationReminders: false,
          communityUpdates: false
        };
        toast.success('All notifications disabled');
        break;
    }

    const newSettings = { ...settings, ...updates };
    setSettings(newSettings);
    onUpdateSettings(updates);
    await saveSettings(newSettings);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-blue-500 px-4 py-3 text-white">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onNavigate('home')}
            className="text-white hover:bg-white/20 p-2 min-h-11"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-medium">Settings</h1>
        </div>
      </div>

      <div className="p-4 pb-20 space-y-6">
        {/* App Preferences */}
        <Card className="p-4">
          <h3 className="font-medium text-foreground mb-4">App Preferences</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Moon className="w-5 h-5 text-muted-foreground" />
                <Label htmlFor="dark-mode" className="text-foreground">Dark Mode</Label>
              </div>
              <Switch
                id="dark-mode"
                checked={isDarkMode}
                onCheckedChange={(checked) => handleSettingToggle('darkMode', checked)}
                disabled={loading}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Mic className="w-5 h-5 text-muted-foreground" />
                <Label htmlFor="voice-assistant" className="text-foreground">Voice Assistant</Label>
              </div>
              <Switch
                id="voice-assistant"
                checked={settings.voiceAssistant}
                onCheckedChange={(checked) => handleSettingToggle('voiceAssistant', checked)}
                disabled={loading}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Globe className="w-5 h-5 text-muted-foreground" />
                <div>
                  <Label htmlFor="location-sharing" className="text-foreground">Location Sharing</Label>
                  <p className="text-xs text-muted-foreground">For personalized recommendations</p>
                </div>
              </div>
              <Switch
                id="location-sharing"
                checked={settings.locationSharing}
                onCheckedChange={(checked) => handleSettingToggle('locationSharing', checked)}
                disabled={loading}
              />
            </div>
          </div>
        </Card>

        {/* Notification Settings */}
        <Card className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-medium text-foreground">Notifications</h3>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleNotificationPreset('essential')}
                disabled={loading}
                className="text-xs min-h-11"
              >
                Essential
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleNotificationPreset('none')}
                disabled={loading}
                className="text-xs min-h-11"
              >
                None
              </Button>
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Bell className="w-5 h-5 text-muted-foreground" />
                <Label htmlFor="push-notifications" className="text-foreground">Push Notifications</Label>
              </div>
              <Switch
                id="push-notifications"
                checked={settings.pushNotifications}
                onCheckedChange={(checked) => handleSettingToggle('pushNotifications', checked)}
                disabled={loading}
              />
            </div>

            {settings.pushNotifications && (
              <div className="ml-8 space-y-3 pl-4 border-l-2 border-gray-100 dark:border-gray-800">
                <div className="flex items-center justify-between">
                  <Label htmlFor="weather-alerts" className="text-sm text-foreground">Weather Alerts</Label>
                  <Switch
                    id="weather-alerts"
                    checked={settings.weatherAlerts}
                    onCheckedChange={(checked) => handleSettingToggle('weatherAlerts', checked)}
                    disabled={loading}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="air-quality-alerts" className="text-sm text-foreground">Air Quality Alerts</Label>
                  <Switch
                    id="air-quality-alerts"
                    checked={settings.airQualityAlerts}
                    onCheckedChange={(checked) => handleSettingToggle('airQualityAlerts', checked)}
                    disabled={loading}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="health-reminders" className="text-sm text-foreground">Health Reminders</Label>
                  <Switch
                    id="health-reminders"
                    checked={settings.healthReminders}
                    onCheckedChange={(checked) => handleSettingToggle('healthReminders', checked)}
                    disabled={loading}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Pill className="w-4 h-4 text-purple-500" />
                    <Label htmlFor="medication-reminders" className="text-sm text-foreground">Medication Reminders</Label>
                  </div>
                  <Switch
                    id="medication-reminders"
                    checked={settings.medicationReminders}
                    onCheckedChange={(checked) => handleSettingToggle('medicationReminders', checked)}
                    disabled={loading}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="community-updates" className="text-sm text-foreground">Community Updates</Label>
                  <Switch
                    id="community-updates"
                    checked={settings.communityUpdates}
                    onCheckedChange={(checked) => handleSettingToggle('communityUpdates', checked)}
                    disabled={loading}
                  />
                </div>
              </div>
            )}
          </div>
        </Card>

        {/* Medication Summary */}
        {userProfile.medications && userProfile.medications.length > 0 && (
          <Card className="p-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Pill className="w-5 h-5 text-purple-500" />
                <h3 className="font-medium text-foreground">Your Medications</h3>
              </div>
              <Button variant="ghost" size="sm" onClick={onEditProfile} className="min-h-11">
                <Edit className="w-4 h-4" />
              </Button>
            </div>
            <div className="space-y-2">
              {userProfile.medications.filter(med => med.isActive).slice(0, 3).map((medication) => (
                <div key={medication.id} className="flex items-center justify-between py-2 px-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <div>
                    <p className="text-sm font-medium text-foreground">{medication.name}</p>
                    <p className="text-xs text-muted-foreground">{medication.dosage} • {medication.frequency.replace('-', ' ')}</p>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {medication.times.length > 0 ? medication.times.join(', ') : 'As needed'}
                  </div>
                </div>
              ))}
              {userProfile.medications.filter(med => med.isActive).length > 3 && (
                <p className="text-xs text-muted-foreground text-center py-2">
                  +{userProfile.medications.filter(med => med.isActive).length - 3} more medications
                </p>
              )}
              {userProfile.medications.filter(med => med.isActive).length === 0 && (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No active medications. Add medications in your health profile.
                </p>
              )}
            </div>
          </Card>
        )}

        {/* Data & Privacy */}
        <Card className="p-4">
          <h3 className="font-medium text-foreground mb-4">Data & Privacy</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="auto-refresh" className="text-foreground">Auto-refresh Data</Label>
                <p className="text-xs text-muted-foreground">Automatically update weather and air quality</p>
              </div>
              <Switch
                id="auto-refresh"
                checked={settings.autoRefresh}
                onCheckedChange={(checked) => handleSettingToggle('autoRefresh', checked)}
                disabled={loading}
              />
            </div>
          </div>
        </Card>

        {/* Health Profile */}
        <Card className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-medium text-foreground">Health Profile</h3>
            <Button variant="ghost" size="sm" onClick={onEditProfile} className="min-h-11">
              <Edit className="w-4 h-4" />
            </Button>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Conditions:</span>
              <span className="text-foreground">
                {[
                  userProfile.hasAsthma && 'Asthma',
                  userProfile.hasDustAllergy && 'Dust Allergy',
                  userProfile.hasPollenAllergy && 'Pollen Allergy',
                  userProfile.hasHeartCondition && 'Heart Condition',
                  userProfile.hasUVSensitivity && 'UV Sensitivity'
                ].filter(Boolean).join(', ') || 'None'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Age Group:</span>
              <span className="text-foreground">{userProfile.ageGroup || 'Not set'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Gender:</span>
              <span className="text-foreground">{userProfile.gender || 'Not set'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Medications:</span>
              <span className="text-foreground">
                {userProfile.medications ? userProfile.medications.filter(med => med.isActive).length : 0} active
              </span>
            </div>
          </div>
        </Card>

        {/* Other Settings */}
        <Card className="p-4">
          <h3 className="font-medium text-foreground mb-4">More Options</h3>
          <div className="space-y-3">
            <Button variant="ghost" className="w-full justify-start min-h-11" size="sm">
              <Globe className="w-5 h-5 mr-3" />
              Language & Region
            </Button>
            <Button variant="ghost" className="w-full justify-start min-h-11" size="sm">
              <Info className="w-5 h-5 mr-3" />
              About & Privacy
            </Button>
            <Button 
              variant="ghost" 
              className="w-full justify-start min-h-11" 
              size="sm"
              onClick={() => onNavigate('profile')}
            >
              <User className="w-5 h-5 mr-3" />
              View Profile
            </Button>
          </div>
        </Card>

        {/* Debug Info (Development only) */}
        {process.env.NODE_ENV === 'development' && (
          <Card className="p-4 bg-gray-50 dark:bg-gray-900">
            <h3 className="font-medium text-foreground mb-2">Debug Info</h3>
            <div className="text-xs text-muted-foreground space-y-1">
              <p>User ID: {userId}</p>
              <p>Settings synced: {loading ? 'Syncing...' : 'Yes'}</p>
              <p>Dark mode: {isDarkMode ? 'Enabled' : 'Disabled'}</p>
              <p>Medication reminders: {settings.medicationReminders ? 'Enabled' : 'Disabled'}</p>
              <p>Active medications: {userProfile.medications ? userProfile.medications.filter(med => med.isActive).length : 0}</p>
            </div>
          </Card>
        )}
      </div>

      <BottomNavigation 
        activeTab="settings" 
        onTabChange={(tab) => {
          const screenMap: { [key: string]: string } = {
            'home': 'home',
            'map': 'parks',
            'alerts': 'alerts',
            'forecast': 'forecast',
            'settings': 'settings'
          };
          if (screenMap[tab]) {
            onNavigate(screenMap[tab]);
          }
        }} 
      />
    </div>
  );
}