import { ArrowLeft, Edit3, Mic } from 'lucide-react';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { BottomNavigation } from './BottomNavigation';

interface ProfileScreenProps {
  onNavigate: (screen: string) => void;
  userProfile: {
    hasAsthma: boolean;
    hasDustAllergy: boolean;
    hasPollenAllergy: boolean;
    hasHeartCondition: boolean;
    hasUVSensitivity: boolean;
    gender: string;
    ageGroup: string;
  };
  onEditProfile: () => void;
}

export function ProfileScreen({ onNavigate, userProfile, onEditProfile }: ProfileScreenProps) {
  // Mock user data
  const userData = {
    name: "John Doe",
    lastUpdated: "June 15, 2023"
  };

  // Mock medications data
  const medications = [
    {
      id: 1,
      name: "Ventolin Inhaler",
      dosage: "100mcg, twice daily",
      icon: "💊",
      active: true
    },
    {
      id: 2,
      name: "Metformin",
      dosage: "500mg, with meals",
      icon: "💊",
      active: true
    }
  ];

  const healthConditions = [
    {
      id: 'asthma',
      name: 'Asthma',
      icon: '🫁',
      value: userProfile.hasAsthma,
      color: 'text-blue-500'
    },
    {
      id: 'dustAllergy',
      name: 'Dust Allergy',
      icon: '🌪️',
      value: userProfile.hasDustAllergy,
      color: 'text-gray-500'
    },
    {
      id: 'heartCondition',
      name: 'Heart Condition',
      icon: '❤️',
      value: userProfile.hasHeartCondition,
      color: 'text-red-500'
    },
    {
      id: 'uvSensitivity',
      name: 'UV Sensitivity',
      icon: '☀️',
      value: userProfile.hasUVSensitivity,
      color: 'text-yellow-500'
    },
    {
      id: 'pollenAllergy',
      name: 'Pollen Allergy',
      icon: '🌸',
      value: userProfile.hasPollenAllergy,
      color: 'text-orange-500'
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-blue-500 px-4 py-3 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onNavigate('home')}
              className="text-white hover:bg-white/20 p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-lg font-medium">My Health Profile</h1>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/20 p-2"
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
              <path d="M10 6a2 2 0 110-4 2 2 0 010 4zM10 12a2 2 0 110-4 2 2 0 010 4zM10 18a2 2 0 110-4 2 2 0 010 4z" />
            </svg>
          </Button>
        </div>
      </div>

      <div className="px-4 pb-20">
        {/* User Info Section */}
        <Card className="p-4 mt-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
              <span className="text-blue-500 text-xl">👤</span>
            </div>
            <div>
              <h2 className="font-medium text-foreground">{userData.name}</h2>
              <p className="text-sm text-muted-foreground">Last updated: {userData.lastUpdated}</p>
            </div>
          </div>
        </Card>

        {/* Privacy Notice */}
        <div className="bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800 rounded-lg p-3 mt-4 flex items-start gap-2">
          <div className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
            <span className="text-white text-xs">ℹ️</span>
          </div>
          <p className="text-sm text-blue-700 dark:text-blue-300">
            Your health information is stored locally on your device
          </p>
        </div>

        {/* Health Conditions */}
        <div className="mt-6">
          <div className="flex items-center gap-2 mb-4">
            <span className="text-red-500">❤️</span>
            <h3 className="font-medium text-foreground">Health Conditions</h3>
          </div>

          <div className="space-y-3">
            {healthConditions.map((condition) => (
              <Card key={condition.id} className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-xl">{condition.icon}</span>
                    <span className="font-medium text-foreground">{condition.name}</span>
                  </div>
                  <Switch
                    checked={condition.value}
                    disabled={true}
                    className="pointer-events-none"
                  />
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Current Medications */}
        <div className="mt-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-medium text-foreground">Current Medications</h3>
            <Button variant="ghost" size="sm" className="text-blue-500 hover:text-blue-600">
              <Edit3 className="w-4 h-4 mr-1" />
              Edit
            </Button>
          </div>

          <div className="space-y-3">
            {medications.map((medication) => (
              <Card key={medication.id} className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-green-100 dark:bg-green-900/20 rounded-lg flex items-center justify-center">
                      <span className="text-green-600 text-sm">{medication.icon}</span>
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{medication.name}</p>
                      <p className="text-sm text-muted-foreground">{medication.dosage}</p>
                    </div>
                  </div>
                  {medication.active && (
                    <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                  )}
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Edit Health Profile Button */}
        <div className="mt-8 flex gap-3">
          <Button 
            onClick={onEditProfile}
            className="flex-1 bg-blue-500 hover:bg-blue-600 text-white"
          >
            <Edit3 className="w-4 h-4 mr-2" />
            Edit Health Profile
          </Button>
          <Button 
            variant="outline"
            size="icon"
            className="border-blue-500 text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950/20"
          >
            <Mic className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <BottomNavigation 
        activeTab="settings" 
        onTabChange={(tab) => {
          const screenMap: { [key: string]: string } = {
            'home': 'home',
            'map': 'parks',
            'alerts': 'alerts',
            'forecast': 'forecast',
            'settings': 'settings'
          };
          if (screenMap[tab]) {
            onNavigate(screenMap[tab]);
          }
        }} 
      />
    </div>
  );
}