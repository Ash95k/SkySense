import { useEffect, useState } from 'react';
import { Shield } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  const [fadeIn, setFadeIn] = useState(false);

  useEffect(() => {
    // Trigger fade-in animation after component mounts
    const timer = setTimeout(() => setFadeIn(true), 100);
    
    // Auto-advance to next screen after 3 seconds
    const autoAdvance = setTimeout(() => {
      onComplete();
    }, 3000);
    
    return () => {
      clearTimeout(timer);
      clearTimeout(autoAdvance);
    };
  }, [onComplete]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-500 via-blue-600 to-purple-700 flex items-center justify-center">
      <div className={`text-center transition-all duration-1000 ${
        fadeIn ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
      }`}>
        {/* App Logo */}
        <div className="mb-6">
          <div className="w-24 h-24 mx-auto bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mb-4">
            <Shield className="w-12 h-12 text-white" />
          </div>
        </div>

        {/* App Name */}
        <h1 className="text-2xl font-medium text-white mb-2">
          SkySense
        </h1>
        <p className="text-white/80 text-sm">
          Your personal air quality guardian
        </p>

        {/* Loading indicator */}
        <div className="mt-8">
          <div className="w-8 h-8 mx-auto border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
        </div>
      </div>
    </div>
  );
}