import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';

export function AirQualityCard() {
  const aqiValue = 87;
  const aqiLevel = "Moderate";
  const aqiColor = "bg-yellow-500";
  
  return (
    <Card className="p-4 bg-card border border-border">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-medium text-foreground">Air Quality Index</h3>
        <Badge variant="outline" className="text-yellow-600 border-yellow-600">
          {aqiLevel}
        </Badge>
      </div>
      
      <div className="flex items-center gap-4 mb-4">
        <div className="text-3xl font-light text-foreground">{aqiValue}</div>
        <div className="flex-1">
          <p className="text-sm text-muted-foreground mb-2">
            Air quality is acceptable for most people
          </p>
          <Progress value={65} className="h-2" />
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4 text-sm">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-orange-400"></div>
            <span className="text-muted-foreground">PM2.5</span>
          </div>
          <span className="font-medium text-foreground">35 μg/m³</span>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
            <span className="text-muted-foreground">PM10</span>
          </div>
          <span className="font-medium text-foreground">58 μg/m³</span>
        </div>
      </div>
    </Card>
  );
}