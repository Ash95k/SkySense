import { ArrowLeft, Bell, Shield, Sun, MapPin, Trash2 } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';

interface NotificationCenterProps {
  onNavigate: (screen: string) => void;
}

interface Notification {
  id: string;
  type: 'mask' | 'uv' | 'park' | 'disaster' | 'general';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
}

export function NotificationCenter({ onNavigate }: NotificationCenterProps) {
  const mockNotifications: Notification[] = [
    {
      id: '1',
      type: 'mask',
      title: 'High Dust Alert',
      message: 'Dust AQI high. Wear N95 mask.',
      timestamp: '5 min ago',
      read: false
    },
    {
      id: '2',
      type: 'uv',
      title: 'UV Warning',
      message: 'UV Index: 8. Apply SPF 30+ sunscreen.',
      timestamp: '1 hour ago',
      read: false
    },
    {
      id: '3',
      type: 'park',
      title: 'Clean Air Spot',
      message: 'Central Park has good air quality for outdoor activities.',
      timestamp: '2 hours ago',
      read: true
    }
  ];

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'mask': return <Shield className="w-5 h-5 text-blue-600" />;
      case 'uv': return <Sun className="w-5 h-5 text-yellow-600" />;
      case 'park': return <MapPin className="w-5 h-5 text-green-600" />;
      default: return <Bell className="w-5 h-5 text-gray-600" />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-blue-500 px-4 py-3 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onNavigate('home')}
              className="text-white hover:bg-white/20 p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-lg font-medium">Notifications</h1>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/20 p-2"
          >
            <Trash2 className="w-5 h-5" />
          </Button>
        </div>
      </div>

      <div className="p-4 space-y-3">
        {mockNotifications.map((notification) => (
          <Card key={notification.id} className={`p-4 ${
            !notification.read ? 'border-blue-200 bg-blue-50/50 dark:border-blue-800 dark:bg-blue-950/10' : ''
          }`}>
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 mt-1">
                {getNotificationIcon(notification.type)}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-medium text-foreground">{notification.title}</h3>
                  {!notification.read && (
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  )}
                </div>
                <p className="text-sm text-muted-foreground mb-2">
                  {notification.message}
                </p>
                <span className="text-xs text-muted-foreground">
                  {notification.timestamp}
                </span>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}