import { useState } from 'react';
import { ArrowLeft, Award, Trophy, Star, Target, Calendar, Zap, Shield, Leaf } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { BottomNavigation } from './BottomNavigation';

interface BadgesScreenProps {
  onNavigate: (screen: string) => void;
}

interface UserBadge {
  id: string;
  name: string;
  description: string;
  icon: string;
  earned: boolean;
  earnedDate?: string;
  category: 'awareness' | 'action' | 'streak' | 'impact';
  progress?: number;
  maxProgress?: number;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
}

interface Streak {
  id: string;
  name: string;
  description: string;
  icon: string;
  currentCount: number;
  category: 'check' | 'avoid' | 'action';
  color: string;
}

export function BadgesScreen({ onNavigate }: BadgesScreenProps) {
  const [selectedTab, setSelectedTab] = useState<'badges' | 'streaks'>('badges');

  const userBadges: UserBadge[] = [
    {
      id: '1',
      name: 'Clean Air Hero',
      description: 'Checked air quality 7 days in a row',
      icon: '🦸',
      earned: true,
      earnedDate: 'July 20, 2024',
      category: 'awareness',
      rarity: 'rare'
    },
    {
      id: '2',
      name: 'Lung Protector',
      description: 'Avoided poor air quality exposure 5 times',
      icon: '🫁',
      earned: true,
      earnedDate: 'July 18, 2024',
      category: 'action',
      rarity: 'common'
    },
    {
      id: '3',
      name: 'Eco Warrior',
      description: 'Completed 10 eco-friendly actions',
      icon: '🌱',
      earned: false,
      category: 'action',
      progress: 7,
      maxProgress: 10,
      rarity: 'epic'
    },
    {
      id: '4',
      name: 'Weather Wizard',
      description: 'Used weather predictions to avoid bad air 20 times',
      icon: '🔮',
      earned: false,
      category: 'awareness',
      progress: 12,
      maxProgress: 20,
      rarity: 'legendary'
    },
    {
      id: '5',
      name: 'Community Helper',
      description: 'Submitted 5 air quality reports',
      icon: '🤝',
      earned: false,
      category: 'impact',
      progress: 2,
      maxProgress: 5,
      rarity: 'rare'
    },
    {
      id: '6',
      name: 'Streak Master',
      description: 'Maintained any streak for 30 days',
      icon: '🔥',
      earned: false,
      category: 'streak',
      progress: 14,
      maxProgress: 30,
      rarity: 'epic'
    }
  ];

  const streaks: Streak[] = [
    {
      id: '1',
      name: 'Daily AQI Check',
      description: 'Check air quality every day',
      icon: '📊',
      currentCount: 7,
      category: 'check',
      color: 'text-blue-500'
    },
    {
      id: '2',
      name: 'Clean Air Seeker',
      description: 'Avoid poor air quality days',
      icon: '🌬️',
      currentCount: 4,
      category: 'avoid',
      color: 'text-green-500'
    },
    {
      id: '3',
      name: 'Eco Action',
      description: 'Take environmental action daily',
      icon: '♻️',
      currentCount: 3,
      category: 'action',
      color: 'text-orange-500'
    },
    {
      id: '4',
      name: 'Mask Defender',
      description: 'Wear mask on high pollution days',
      icon: '😷',
      currentCount: 2,
      category: 'action',
      color: 'text-purple-500'
    }
  ];

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'border-gray-300 bg-gray-50 dark:bg-gray-900/20';
      case 'rare': return 'border-blue-300 bg-blue-50 dark:bg-blue-900/20';
      case 'epic': return 'border-purple-300 bg-purple-50 dark:bg-purple-900/20';
      case 'legendary': return 'border-yellow-300 bg-yellow-50 dark:bg-yellow-900/20';
      default: return 'border-gray-300 bg-gray-50';
    }
  };

  const getRarityText = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'text-gray-600';
      case 'rare': return 'text-blue-600';
      case 'epic': return 'text-purple-600';
      case 'legendary': return 'text-yellow-600';
      default: return 'text-gray-600';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'awareness': return <Target className="w-4 h-4" />;
      case 'action': return <Zap className="w-4 h-4" />;
      case 'streak': return <Calendar className="w-4 h-4" />;
      case 'impact': return <Star className="w-4 h-4" />;
      default: return <Award className="w-4 h-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-blue-500 px-4 py-3 text-white">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onNavigate('home')}
            className="text-white hover:bg-white/20 p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-medium">Achievements</h1>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="px-4 py-3">
        <div className="flex bg-gray-100 dark:bg-gray-800 rounded-lg p-1">
          <Button
            variant={selectedTab === 'badges' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setSelectedTab('badges')}
            className={`flex-1 ${selectedTab === 'badges' ? 'bg-blue-500 text-white' : 'text-gray-600 dark:text-gray-300'}`}
          >
            <Trophy className="w-4 h-4 mr-2" />
            Badges
          </Button>
          <Button
            variant={selectedTab === 'streaks' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setSelectedTab('streaks')}
            className={`flex-1 ${selectedTab === 'streaks' ? 'bg-blue-500 text-white' : 'text-gray-600 dark:text-gray-300'}`}
          >
            <Zap className="w-4 h-4 mr-2" />
            Streaks
          </Button>
        </div>
      </div>

      <div className="px-4 pb-20 space-y-4">
        {selectedTab === 'badges' && (
          <>
            {/* User Stats */}
            <Card className="p-4 bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-950/20 dark:to-orange-950/20 border-yellow-200 dark:border-yellow-800">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-light text-foreground">
                    {userBadges.filter(b => b.earned).length}/{userBadges.length}
                  </div>
                  <div className="text-sm text-muted-foreground">Badges Earned</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-medium text-yellow-600">Level 3</div>
                  <div className="text-xs text-muted-foreground">Eco Champion</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-medium text-orange-600">450</div>
                  <div className="text-xs text-muted-foreground">Total Points</div>
                </div>
              </div>
            </Card>

            {/* Badges Grid */}
            <div className="space-y-4">
              <h3 className="font-medium text-foreground">Your Badges</h3>
              
              <div className="grid grid-cols-2 gap-3">
                {userBadges.map((badge) => (
                  <Card 
                    key={badge.id} 
                    className={`p-4 ${getRarityColor(badge.rarity)} ${badge.earned ? '' : 'opacity-60'}`}
                  >
                    <div className="text-center">
                      <div className="text-3xl mb-2">{badge.icon}</div>
                      <h4 className="font-medium text-foreground text-sm mb-1">{badge.name}</h4>
                      <p className="text-xs text-muted-foreground mb-3 leading-relaxed">
                        {badge.description}
                      </p>
                      
                      <div className="flex items-center justify-center gap-1 mb-2">
                        {getCategoryIcon(badge.category)}
                        <Badge variant="outline" className={`text-xs ${getRarityText(badge.rarity)}`}>
                          {badge.rarity}
                        </Badge>
                      </div>

                      {badge.earned ? (
                        <div className="text-xs text-green-600 font-medium">
                          ✓ Earned {badge.earnedDate}
                        </div>
                      ) : badge.progress !== undefined && badge.maxProgress !== undefined ? (
                        <div>
                          <div className="text-xs text-muted-foreground mb-1">
                            {badge.progress}/{badge.maxProgress}
                          </div>
                          <Progress 
                            value={(badge.progress / badge.maxProgress) * 100} 
                            className="h-1"
                          />
                        </div>
                      ) : (
                        <div className="text-xs text-muted-foreground">Not earned yet</div>
                      )}
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </>
        )}

        {selectedTab === 'streaks' && (
          <>
            {/* Streak Overview */}
            <Card className="p-4 bg-gradient-to-r from-orange-50 to-red-50 dark:from-orange-950/20 dark:to-red-950/20 border-orange-200 dark:border-orange-800">
              <div className="text-center">
                <div className="text-3xl mb-2">🔥</div>
                <div className="text-xl font-medium text-foreground mb-1">7 Day Streak!</div>
                <div className="text-sm text-muted-foreground">Your longest current streak</div>
              </div>
            </Card>

            {/* Active Streaks */}
            <div className="space-y-4">
              <h3 className="font-medium text-foreground">Active Streaks</h3>
              
              <div className="space-y-3">
                {streaks.map((streak) => (
                  <Card key={streak.id} className="p-4">
                    <div className="flex items-center gap-4">
                      <div className="text-2xl">{streak.icon}</div>
                      
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-medium text-foreground">{streak.name}</h4>
                          <div className={`text-lg font-medium ${streak.color}`}>
                            {streak.currentCount}
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {streak.description}
                        </p>
                      </div>

                      <div className="text-center">
                        <div className={`text-xl font-medium ${streak.color}`}>
                          {streak.currentCount}
                        </div>
                        <div className="text-xs text-muted-foreground">days</div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              {/* Streak Tips */}
              <Card className="p-4 bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-white text-lg">💡</span>
                  </div>
                  <div>
                    <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">
                      Streak Tips
                    </h4>
                    <div className="space-y-1 text-sm text-blue-800 dark:text-blue-200">
                      <p>• Check the app daily to maintain your streaks</p>
                      <p>• Set reminders for air quality checks</p>
                      <p>• Small consistent actions build big results</p>
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          </>
        )}
      </div>

      <BottomNavigation 
        activeTab="home" 
        onTabChange={(tab) => {
          const screenMap: { [key: string]: string } = {
            'home': 'home',
            'map': 'parks',
            'alerts': 'alerts',
            'forecast': 'forecast',
            'settings': 'settings'
          };
          if (screenMap[tab]) {
            onNavigate(screenMap[tab]);
          }
        }} 
      />
    </div>
  );
}