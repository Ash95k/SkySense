import { useState } from 'react';
import { ArrowLeft, Filter, Search, Map as MapIcon, List, ChevronDown } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { BottomNavigation } from './BottomNavigation';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { InteractiveMap } from './InteractiveMap';

interface NearbyParksScreenProps {
  onNavigate: (screen: string) => void;
}

interface Park {
  id: number;
  name: string;
  distance: string;
  hours: string;
  aqi: number;
  aqiLabel: string;
  safetyStatus: string;
  image: string;
  isOpen: boolean;
  lat: number;
  lng: number;
}

export function NearbyParksScreen({ onNavigate }: NearbyParksScreenProps) {
  const [viewMode, setViewMode] = useState<'map' | 'list'>('map');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPark, setSelectedPark] = useState<Park | null>(null);

  const parks: Park[] = [
    {
      id: 1,
      name: 'Riverside Park',
      distance: '0.8 km',
      hours: 'Open 6:00 AM - 10:00 PM',
      aqi: 32,
      aqiLabel: 'AQI 32',
      safetyStatus: 'Safe to visit',
      image: 'https://images.unsplash.com/photo-1662815805367-4949123b42fe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyaXZlcnNpZGUlMjBwYXJrJTIwdHJlZXMlMjB3YXRlcnxlbnwxfHx8fDE3NTUxODI0OTZ8MA&ixlib=rb-4.1.0&q=80&w=400&utm_source=figma&utm_medium=referral',
      isOpen: true,
      lat: 40.7614,
      lng: -73.9776
    },
    {
      id: 2,
      name: 'Central Gardens',
      distance: '1.2 km',
      hours: 'Open 5:00 AM - 11:00 PM',
      aqi: 78,
      aqiLabel: 'AQI 78',
      safetyStatus: 'Moderate air',
      image: 'https://images.unsplash.com/photo-1687373604501-4cc46e6e40b3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib3RhbmljYWwlMjBnYXJkZW4lMjBmbG93ZXJzfGVufDF8fHx8MTc1NTE4MjQ5OXww&ixlib=rb-4.1.0&q=80&w=400&utm_source=figma&utm_medium=referral',
      isOpen: true,
      lat: 40.7505,
      lng: -73.9934
    },
    {
      id: 3,
      name: 'Lakeside Park',
      distance: '1.7 km',
      hours: 'Open 24 hours',
      aqi: 29,
      aqiLabel: 'AQI 29',
      safetyStatus: 'Safe to visit',
      image: 'https://images.unsplash.com/photo-1675732438756-c9eb4892a768?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYWtlc2lkZSUyMHBhcmslMjB3YXRlciUyMG5hdHVyZXxlbnwxfHx8fDE3NTUxODI1MDN8MA&ixlib=rb-4.1.0&q=80&w=400&utm_source=figma&utm_medium=referral',
      isOpen: true,
      lat: 40.7489,
      lng: -73.9680
    },
    {
      id: 4,
      name: 'Factory District Park',
      distance: '2.3 km',
      hours: 'Open 7:00 AM - 8:00 PM',
      aqi: 112,
      aqiLabel: 'AQI 112',
      safetyStatus: 'Not recommended',
      image: 'https://images.unsplash.com/photo-1644380344134-c8986ef44b59?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1cmJhbiUyMHBhcmslMjBjaXR5JTIwZ3JlZW4lMjBzcGFjZXxlbnwxfHx8fDE3NTUxODI1MDd8MA&ixlib=rb-4.1.0&q=80&w=400&utm_source=figma&utm_medium=referral',
      isOpen: true,
      lat: 40.7308,
      lng: -73.9973
    },
    {
      id: 5,
      name: 'Community Garden',
      distance: '2.5 km',
      hours: 'Open 6:00 AM - 7:00 PM',
      aqi: 41,
      aqiLabel: 'AQI 41',
      safetyStatus: 'Safe to visit',
      image: 'https://images.unsplash.com/photo-1687878269800-c92f8d327aae?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21tdW5pdHklMjBnYXJkZW4lMjB2ZWdldGFibGVzJTIwcGxhbnRzfGVufDF8fHx8MTc1NTE4MjUxMHww&ixlib=rb-4.1.0&q=80&w=400&utm_source=figma&utm_medium=referral',
      isOpen: true,
      lat: 40.7282,
      lng: -73.9942
    }
  ];

  const getAQIColor = (aqi: number) => {
    if (aqi <= 50) return 'bg-green-500';
    if (aqi <= 100) return 'bg-orange-500';
    return 'bg-red-500';
  };

  const getAQITextColor = (aqi: number) => {
    if (aqi <= 50) return 'text-green-700';
    if (aqi <= 100) return 'text-orange-700';
    return 'text-red-700';
  };

  const getSafetyColor = (status: string) => {
    if (status === 'Safe to visit') return 'text-green-600 bg-green-50';
    if (status === 'Moderate air') return 'text-orange-600 bg-orange-50';
    return 'text-red-600 bg-red-50';
  };

  const getSafetyIcon = (status: string) => {
    if (status === 'Safe to visit') return '✓';
    if (status === 'Moderate air') return '⚠';
    return '△';
  };

  const filteredParks = parks.filter(park =>
    park.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-blue-500 px-4 py-3 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onNavigate('home')}
              className="text-white hover:bg-white/20 p-2 min-h-11"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-lg font-medium">Nearby Parks</h1>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/20 p-2 min-h-11"
          >
            <Filter className="w-5 h-5" />
          </Button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="px-4 py-3 bg-gray-50 dark:bg-gray-900">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="Search parks..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-500 min-h-11"
          />
        </div>
      </div>

      {/* Map/List Toggle */}
      <div className="px-4 py-3">
        <div className="flex bg-gray-100 dark:bg-gray-800 rounded-lg p-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setViewMode('map')}
            className={`flex-1 transition-all min-h-11 ${viewMode === 'map' ? 'bg-blue-500 text-white hover:bg-blue-600' : 'text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-gray-100'}`}
          >
            <MapIcon className="w-4 h-4 mr-2" />
            Map
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setViewMode('list')}
            className={`flex-1 transition-all min-h-11 ${viewMode === 'list' ? 'bg-blue-500 text-white hover:bg-blue-600' : 'text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-gray-100'}`}
          >
            <List className="w-4 h-4 mr-2" />
            List
          </Button>
        </div>
      </div>

      {/* Map View - Always visible when map mode is selected */}
      {viewMode === 'map' && (
        <div className="px-4 mb-4">
          <div className="h-48 rounded-lg overflow-hidden">
            <InteractiveMap 
              markers={filteredParks.map(park => ({
                id: park.id.toString(),
                lat: park.lat,
                lng: park.lng,
                name: park.name,
                type: 'park' as const,
                aqi: park.aqi
              }))}
              onLocationSelect={(location) => {
                const park = parks.find(p => 
                  Math.abs(p.lat - location.lat) < 0.001 && 
                  Math.abs(p.lng - location.lng) < 0.001
                );
                if (park) setSelectedPark(park);
              }}
              height="h-full"
              showControls={false}
            />
          </div>
        </div>
      )}

      {/* Parks List */}
      <div className="px-4 pb-24">
        {/* List Header */}
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-medium text-foreground">Parks Near You</h2>
          <span className="text-sm text-muted-foreground">{filteredParks.length} parks found</span>
        </div>

        {/* Parks List */}
        <div className="space-y-4">
          {filteredParks.map((park) => (
            <div 
              key={park.id} 
              className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden touch-manipulation"
            >
              <div className="flex">
                {/* Park Image */}
                <div className="w-20 h-20 flex-shrink-0">
                  <ImageWithFallback
                    src={park.image}
                    alt={park.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Park Details */}
                <div className="flex-1 p-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="font-medium text-foreground mb-1">{park.name}</h3>
                      <p className="text-sm text-muted-foreground mb-2">{park.hours}</p>
                      
                      {/* AQI and Safety Status */}
                      <div className="flex items-center gap-2 flex-wrap">
                        <div className="flex items-center gap-1">
                          <div className={`w-3 h-3 rounded-full ${getAQIColor(park.aqi)}`}></div>
                          <span className={`text-xs font-medium ${getAQITextColor(park.aqi)}`}>
                            {park.aqiLabel}
                          </span>
                        </div>
                        
                        <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs ${getSafetyColor(park.safetyStatus)}`}>
                          <span>{getSafetyIcon(park.safetyStatus)}</span>
                          <span>{park.safetyStatus}</span>
                        </div>
                      </div>
                    </div>
                    
                    {/* Distance */}
                    <div className="text-right">
                      <span className="text-sm font-medium text-foreground">{park.distance}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredParks.length === 0 && (
          <div className="text-center py-8">
            <p className="text-muted-foreground">No parks found matching your search.</p>
          </div>
        )}
      </div>

      <BottomNavigation 
        activeTab="map" 
        onTabChange={(tab) => {
          const screenMap: { [key: string]: string } = {
            'home': 'home',
            'map': 'parks',
            'alerts': 'alerts',
            'forecast': 'forecast',
            'settings': 'settings'
          };
          if (screenMap[tab]) {
            onNavigate(screenMap[tab]);
          }
        }} 
      />
    </div>
  );
}