import { Card } from './ui/card';
import { Shield, Shirt, Umbrella, Activity, Sun, Wind, Heart } from 'lucide-react';

interface UserProfile {
  hasAsthma: boolean;
  hasDustAllergy: boolean;
  hasPollenAllergy: boolean;
  hasHeartCondition: boolean;
  hasUVSensitivity: boolean;
  gender: string;
  ageGroup: string;
}

interface RecommendationCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  iconBg: string;
}

function RecommendationCard({ icon, title, description, iconBg }: RecommendationCardProps) {
  return (
    <Card className="p-3 bg-card border border-border hover:shadow-sm transition-shadow">
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 rounded-lg ${iconBg} flex items-center justify-center flex-shrink-0`}>
          {icon}
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="font-medium text-foreground mb-1">{title}</h4>
          <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
        </div>
      </div>
    </Card>
  );
}

interface RecommendationsSectionProps {
  userProfile: UserProfile;
}

export function RecommendationsSection({ userProfile }: RecommendationsSectionProps) {
  const getPersonalizedRecommendations = () => {
    const recommendations = [];

    // Base weather recommendations
    recommendations.push({
      icon: <Shirt className="w-5 h-5 text-green-600" />,
      title: "Light jacket suggested",
      description: "Temperature will drop to 18°C this evening",
      iconBg: "bg-green-100 dark:bg-green-900/30"
    });

    recommendations.push({
      icon: <Umbrella className="w-5 h-5 text-purple-600" />,
      title: "Carry an umbrella",
      description: "30% chance of rain this evening",
      iconBg: "bg-purple-100 dark:bg-purple-900/30"
    });

    // Health-based recommendations
    if (userProfile.hasAsthma || userProfile.hasDustAllergy || userProfile.hasPollenAllergy) {
      recommendations.unshift({
        icon: <Shield className="w-5 h-5 text-blue-600" />,
        title: "Wear an N95 mask",
        description: userProfile.hasPollenAllergy ? "Protects against pollen and particles (AQI: 87)" : "Protects against PM2.5 particles (AQI: 87)",
        iconBg: "bg-blue-100 dark:bg-blue-900/30"
      });
    }

    if (userProfile.hasUVSensitivity) {
      recommendations.push({
        icon: <Sun className="w-5 h-5 text-yellow-600" />,
        title: "UV Protection Needed",
        description: "UV Index: 5. Use SPF 30+ sunscreen",
        iconBg: "bg-yellow-100 dark:bg-yellow-900/30"
      });
    }

    // Skincare recommendations based on weather conditions
    const humidity = 42; // Current humidity level
    const uvIndex = 7; // Current UV index
    
    if (humidity < 50) {
      recommendations.push({
        icon: <Heart className="w-5 h-5 text-pink-600" />,
        title: "Skin Hydration Alert",
        description: `Low humidity (${humidity}%) - use extra moisturizer and hydrating serum`,
        iconBg: "bg-pink-100 dark:bg-pink-900/30"
      });
    }
    
    if (uvIndex >= 6) {
      recommendations.push({
        icon: <Heart className="w-5 h-5 text-orange-600" />,
        title: "Sunscreen Essential",
        description: `High UV Index (${uvIndex}) - apply SPF 50+ every 2 hours`,
        iconBg: "bg-orange-100 dark:bg-orange-900/30"
      });
    }

    if (userProfile.hasHeartCondition) {
      recommendations.push({
        icon: <Activity className="w-5 h-5 text-red-600" />,
        title: "Light Exercise Only",
        description: "High AQI may affect cardiovascular health",
        iconBg: "bg-red-100 dark:bg-red-900/30"
      });
    } else {
      recommendations.push({
        icon: <Activity className="w-5 h-5 text-teal-600" />,
        title: "Outdoor Activity Status",
        description: "Moderate conditions - take breaks if needed",
        iconBg: "bg-teal-100 dark:bg-teal-900/30"
      });
    }

    // Age-specific recommendations
    if (userProfile.ageGroup === 'over-65' || userProfile.ageGroup === 'under-18') {
      recommendations.push({
        icon: <Wind className="w-5 h-5 text-indigo-600" />,
        title: "Extra Precautions",
        description: "Sensitive group - limit exposure duration",
        iconBg: "bg-indigo-100 dark:bg-indigo-900/30"
      });
    }

    return recommendations.slice(0, 5); // Limit to 5 recommendations to include skincare
  };

  const recommendations = getPersonalizedRecommendations();

  return (
    <div>
      <h3 className="font-medium text-foreground mb-3">Personalized Recommendations</h3>
      <div className="space-y-3">
        {recommendations.map((rec, index) => (
          <RecommendationCard
            key={index}
            icon={rec.icon}
            title={rec.title}
            description={rec.description}
            iconBg={rec.iconBg}
          />
        ))}
      </div>
    </div>
  );
}