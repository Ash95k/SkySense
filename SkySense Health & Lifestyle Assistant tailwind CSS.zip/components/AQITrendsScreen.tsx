import { ArrowLeft, TrendingDown, TrendingUp } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';

interface AQITrendsScreenProps {
  onNavigate: (screen: string) => void;
}

export function AQITrendsScreen({ onNavigate }: AQITrendsScreenProps) {
  // Mock chart data
  const mockData = [
    { time: '6 AM', pm25: 35, pm10: 58 },
    { time: '9 AM', pm25: 42, pm10: 65 },
    { time: '12 PM', pm25: 55, pm10: 78 },
    { time: '3 PM', pm25: 48, pm10: 71 },
    { time: '6 PM', pm25: 38, pm10: 62 },
    { time: '9 PM', pm25: 32, pm10: 55 }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-blue-500 px-4 py-3 text-white">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onNavigate('home')}
            className="text-white hover:bg-white/20 p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-medium">AQI Trends</h1>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Current Status */}
        <Card className="p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-medium text-foreground">Current Air Quality</h3>
            <Badge variant="outline" className="text-yellow-600 border-yellow-600">
              Moderate
            </Badge>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <div className="text-2xl font-light text-foreground">42</div>
              <div className="text-sm text-muted-foreground">PM2.5 μg/m³</div>
              <div className="flex items-center justify-center gap-1 text-green-600">
                <TrendingDown className="w-3 h-3" />
                <span className="text-xs">Improving</span>
              </div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-light text-foreground">65</div>
              <div className="text-sm text-muted-foreground">PM10 μg/m³</div>
              <div className="flex items-center justify-center gap-1 text-red-600">
                <TrendingUp className="w-3 h-3" />
                <span className="text-xs">Rising</span>
              </div>
            </div>
          </div>
        </Card>

        {/* Chart Placeholder */}
        <Card className="p-4">
          <h3 className="font-medium text-foreground mb-4">24-Hour Trend</h3>
          <div className="space-y-3">
            {mockData.map((item, index) => (
              <div key={index} className="flex items-center gap-4">
                <div className="w-12 text-sm text-muted-foreground">{item.time}</div>
                <div className="flex-1 flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-orange-400"></div>
                  <div className="text-sm">PM2.5: {item.pm25}</div>
                </div>
                <div className="flex-1 flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-yellow-400"></div>
                  <div className="text-sm">PM10: {item.pm10}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Health Impact */}
        <Card className="p-4 bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800">
          <h3 className="font-medium text-blue-900 dark:text-blue-100 mb-2">
            Health Impact Analysis
          </h3>
          <p className="text-sm text-blue-800 dark:text-blue-200">
            Based on current trends, air quality is expected to improve by evening. 
            Consider outdoor activities after 6 PM for better conditions.
          </p>
        </Card>
      </div>
    </div>
  );
}