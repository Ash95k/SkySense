import { useState } from 'react';
import { ArrowLeft, MoreVertical, ChevronLeft, ChevronRight, Sun, Cloud, CloudRain, Wind, Droplet, Eye, Gauge, AlertTriangle, Thermometer, Umbrella, Shirt, Heart } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card } from './ui/card';
import { BottomNavigation } from './BottomNavigation';

interface WeeklyForecastScreenProps {
  onNavigate: (screen: string) => void;
}

interface DayDetails {
  date: string;
  day: string;
  isToday: boolean;
  isPast: boolean;
  weather: {
    condition: string;
    icon: React.ReactNode;
    temp: number;
    high: number;
    low: number;
    feelsLike: number;
    windSpeed: number;
    windDirection: string;
    humidity: number;
    pressure: number;
    visibility: number;
    uvIndex: number;
    precipitation: number;
    dewPoint: number;
  };
  airQuality: {
    aqi: number;
    level: string;
    color: string;
    pm25: number;
    pm10: number;
    description: string;
  };
  recommendations: {
    mask: string;
    activity: string;
    clothing: string;
    skincare: string;
  };
  hourlyForecast: {
    time: string;
    icon: React.ReactNode;
    temp: number;
    aqi: number;
    precipitation: number;
  }[];
  alerts: {
    type: string;
    message: string;
    color: string;
  }[];
}

export function WeeklyForecastScreen({ onNavigate }: WeeklyForecastScreenProps) {
  const [currentDayIndex, setCurrentDayIndex] = useState(3); // Start with today (index 3)

  const weeklyDetails: DayDetails[] = [
    {
      date: "Jul 25",
      day: "Thu",
      isToday: false,
      isPast: true,
      weather: {
        condition: "Partly Cloudy",
        icon: <Cloud className="w-12 h-12 text-gray-500" />,
        temp: 69,
        high: 74,
        low: 56,
        feelsLike: 71,
        windSpeed: 7,
        windDirection: "NW",
        humidity: 58,
        pressure: 1012,
        visibility: 9,
        uvIndex: 6,
        precipitation: 0,
        dewPoint: 52
      },
      airQuality: {
        aqi: 45,
        level: "Good",
        color: "bg-green-500",
        pm25: 18,
        pm10: 28,
        description: "Air quality is satisfactory"
      },
      recommendations: {
        mask: "No mask needed",
        activity: "Great for outdoor activities",
        clothing: "Light layers recommended",
        skincare: "Use moisturizer to combat dry air. Apply SPF 30+ sunscreen for UV protection."
      },
      hourlyForecast: [
        { time: "9AM", icon: <Sun className="w-4 h-4 text-yellow-500" />, temp: 62, aqi: 42, precipitation: 0 },
        { time: "12PM", icon: <Cloud className="w-4 h-4 text-gray-500" />, temp: 68, aqi: 45, precipitation: 0 },
        { time: "3PM", icon: <Cloud className="w-4 h-4 text-gray-500" />, temp: 72, aqi: 48, precipitation: 0 },
        { time: "6PM", icon: <Cloud className="w-4 h-4 text-gray-500" />, temp: 70, aqi: 46, precipitation: 0 },
        { time: "9PM", icon: <Cloud className="w-4 h-4 text-gray-500" />, temp: 65, aqi: 43, precipitation: 0 }
      ],
      alerts: []
    },
    {
      date: "Jul 26",
      day: "Fri",
      isToday: false,
      isPast: true,
      weather: {
        condition: "Sunny",
        icon: <Sun className="w-12 h-12 text-yellow-500" />,
        temp: 75,
        high: 78,
        low: 59,
        feelsLike: 77,
        windSpeed: 5,
        windDirection: "W",
        humidity: 45,
        pressure: 1018,
        visibility: 10,
        uvIndex: 8,
        precipitation: 0,
        dewPoint: 48
      },
      airQuality: {
        aqi: 62,
        level: "Moderate",
        color: "bg-yellow-500",
        pm25: 28,
        pm10: 35,
        description: "Air quality is acceptable for most people"
      },
      recommendations: {
        mask: "Consider mask for sensitive individuals",
        activity: "Good for most outdoor activities",
        clothing: "Sunscreen and hat recommended",
        skincare: "Apply broad-spectrum SPF 50+ sunscreen every 2 hours. Use hydrating serum due to low humidity."
      },
      hourlyForecast: [
        { time: "9AM", icon: <Sun className="w-4 h-4 text-yellow-500" />, temp: 65, aqi: 58, precipitation: 0 },
        { time: "12PM", icon: <Sun className="w-4 h-4 text-yellow-500" />, temp: 72, aqi: 62, precipitation: 0 },
        { time: "3PM", icon: <Sun className="w-4 h-4 text-yellow-500" />, temp: 76, aqi: 65, precipitation: 0 },
        { time: "6PM", icon: <Sun className="w-4 h-4 text-yellow-500" />, temp: 74, aqi: 63, precipitation: 0 },
        { time: "9PM", icon: <Sun className="w-4 h-4 text-yellow-500" />, temp: 68, aqi: 60, precipitation: 0 }
      ],
      alerts: []
    },
    {
      date: "Jul 27",
      day: "Sat",
      isToday: false,
      isPast: true,
      weather: {
        condition: "Light Rain",
        icon: <CloudRain className="w-12 h-12 text-blue-500" />,
        temp: 64,
        high: 67,
        low: 54,
        feelsLike: 62,
        windSpeed: 12,
        windDirection: "SW",
        humidity: 78,
        pressure: 1008,
        visibility: 6,
        uvIndex: 3,
        precipitation: 85,
        dewPoint: 58
      },
      airQuality: {
        aqi: 28,
        level: "Good",
        color: "bg-green-500",
        pm25: 12,
        pm10: 18,
        description: "Air quality is good - rain cleared pollutants"
      },
      recommendations: {
        mask: "No mask needed",
        activity: "Indoor activities recommended",
        clothing: "Waterproof jacket and umbrella",
        skincare: "Extra moisturizing needed due to high humidity. Use gentle cleanser and waterproof makeup."
      },
      hourlyForecast: [
        { time: "9AM", icon: <CloudRain className="w-4 h-4 text-blue-500" />, temp: 58, aqi: 25, precipitation: 70 },
        { time: "12PM", icon: <CloudRain className="w-4 h-4 text-blue-500" />, temp: 62, aqi: 28, precipitation: 85 },
        { time: "3PM", icon: <CloudRain className="w-4 h-4 text-blue-500" />, temp: 65, aqi: 30, precipitation: 90 },
        { time: "6PM", icon: <CloudRain className="w-4 h-4 text-blue-500" />, temp: 63, aqi: 28, precipitation: 75 },
        { time: "9PM", icon: <Cloud className="w-4 h-4 text-gray-500" />, temp: 59, aqi: 26, precipitation: 20 }
      ],
      alerts: []
    },
    {
      date: "Jul 28",
      day: "Today",
      isToday: true,
      isPast: false,
      weather: {
        condition: "Mostly Sunny",
        icon: <Sun className="w-12 h-12 text-yellow-500" />,
        temp: 68,
        high: 72,
        low: 58,
        feelsLike: 70,
        windSpeed: 8,
        windDirection: "NW",
        humidity: 42,
        pressure: 1015,
        visibility: 10,
        uvIndex: 7,
        precipitation: 0,
        dewPoint: 46
      },
      airQuality: {
        aqi: 52,
        level: "Moderate",
        color: "bg-yellow-500",
        pm25: 22,
        pm10: 32,
        description: "Air quality is acceptable for most people"
      },
      recommendations: {
        mask: "Optional for sensitive individuals",
        activity: "Great for outdoor activities",
        clothing: "Light layers with sun protection",
        skincare: "Use SPF 30+ sunscreen and reapply frequently. Hydrate well due to moderate humidity levels."
      },
      hourlyForecast: [
        { time: "Now", icon: <Sun className="w-4 h-4 text-yellow-500" />, temp: 68, aqi: 52, precipitation: 0 },
        { time: "2PM", icon: <Sun className="w-4 h-4 text-yellow-500" />, temp: 71, aqi: 55, precipitation: 0 },
        { time: "5PM", icon: <Sun className="w-4 h-4 text-yellow-500" />, temp: 72, aqi: 54, precipitation: 0 },
        { time: "8PM", icon: <Sun className="w-4 h-4 text-yellow-500" />, temp: 69, aqi: 50, precipitation: 0 },
        { time: "11PM", icon: <Cloud className="w-4 h-4 text-gray-500" />, temp: 64, aqi: 48, precipitation: 0 }
      ],
      alerts: []
    },
    {
      date: "Jul 29",
      day: "Mon",
      isToday: false,
      isPast: false,
      weather: {
        condition: "Partly Cloudy",
        icon: <Cloud className="w-12 h-12 text-gray-500" />,
        temp: 70,
        high: 73,
        low: 56,
        feelsLike: 72,
        windSpeed: 6,
        windDirection: "W",
        humidity: 48,
        pressure: 1017,
        visibility: 9,
        uvIndex: 6,
        precipitation: 10,
        dewPoint: 49
      },
      airQuality: {
        aqi: 35,
        level: "Good",
        color: "bg-green-500",
        pm25: 15,
        pm10: 22,
        description: "Air quality is good for everyone"
      },
      recommendations: {
        mask: "No mask needed",
        activity: "Perfect for outdoor activities",
        clothing: "Comfortable layers",
        skincare: "Light moisturizer sufficient. Apply SPF 30+ for UV protection with moderate humidity comfort."
      },
      hourlyForecast: [
        { time: "9AM", icon: <Cloud className="w-4 h-4 text-gray-500" />, temp: 62, aqi: 32, precipitation: 0 },
        { time: "12PM", icon: <Cloud className="w-4 h-4 text-gray-500" />, temp: 68, aqi: 35, precipitation: 5 },
        { time: "3PM", icon: <Cloud className="w-4 h-4 text-gray-500" />, temp: 71, aqi: 38, precipitation: 10 },
        { time: "6PM", icon: <Cloud className="w-4 h-4 text-gray-500" />, temp: 69, aqi: 36, precipitation: 5 },
        { time: "9PM", icon: <Cloud className="w-4 h-4 text-gray-500" />, temp: 65, aqi: 33, precipitation: 0 }
      ],
      alerts: []
    },
    {
      date: "Jul 30",
      day: "Tue",
      isToday: false,
      isPast: false,
      weather: {
        condition: "Cloudy",
        icon: <Cloud className="w-12 h-12 text-gray-500" />,
        temp: 68,
        high: 71,
        low: 55,
        feelsLike: 69,
        windSpeed: 9,
        windDirection: "SW",
        humidity: 52,
        pressure: 1013,
        visibility: 8,
        uvIndex: 5,
        precipitation: 20,
        dewPoint: 51
      },
      airQuality: {
        aqi: 66,
        level: "Moderate",
        color: "bg-yellow-500",
        pm25: 30,
        pm10: 38,
        description: "Sensitive groups should limit outdoor exposure"
      },
      recommendations: {
        mask: "Recommended for sensitive individuals",
        activity: "Limit prolonged outdoor activities",
        clothing: "Layer for changing conditions",
        skincare: "Use gentle, fragrance-free moisturizer. Higher humidity may cause breakouts - use oil-free products."
      },
      hourlyForecast: [
        { time: "9AM", icon: <Cloud className="w-4 h-4 text-gray-500" />, temp: 60, aqi: 62, precipitation: 15 },
        { time: "12PM", icon: <Cloud className="w-4 h-4 text-gray-500" />, temp: 66, aqi: 66, precipitation: 20 },
        { time: "3PM", icon: <Cloud className="w-4 h-4 text-gray-500" />, temp: 69, aqi: 69, precipitation: 25 },
        { time: "6PM", icon: <Cloud className="w-4 h-4 text-gray-500" />, temp: 67, aqi: 67, precipitation: 18 },
        { time: "9PM", icon: <Cloud className="w-4 h-4 text-gray-500" />, temp: 63, aqi: 64, precipitation: 10 }
      ],
      alerts: []
    },
    {
      date: "Jul 31",
      day: "Wed",
      isToday: false,
      isPast: false,
      weather: {
        condition: "Hot & Sunny",
        icon: <Sun className="w-12 h-12 text-yellow-500" />,
        temp: 78,
        high: 82,
        low: 61,
        feelsLike: 85,
        windSpeed: 4,
        windDirection: "E",
        humidity: 38,
        pressure: 1020,
        visibility: 10,
        uvIndex: 9,
        precipitation: 0,
        dewPoint: 45
      },
      airQuality: {
        aqi: 89,
        level: "Moderate",
        color: "bg-yellow-500",
        pm25: 42,
        pm10: 55,
        description: "Sensitive groups should reduce outdoor activities"
      },
      recommendations: {
        mask: "Recommended for sensitive individuals",
        activity: "Avoid prolonged outdoor exposure",
        clothing: "Light, breathable fabrics with sun protection",
        skincare: "ESSENTIAL: SPF 50+ broad-spectrum sunscreen every 2 hours. Hydrate intensively due to heat and low humidity."
      },
      hourlyForecast: [
        { time: "9AM", icon: <Sun className="w-4 h-4 text-yellow-500" />, temp: 68, aqi: 85, precipitation: 0 },
        { time: "12PM", icon: <Sun className="w-4 h-4 text-yellow-500" />, temp: 76, aqi: 89, precipitation: 0 },
        { time: "3PM", icon: <Sun className="w-4 h-4 text-yellow-500" />, temp: 80, aqi: 92, precipitation: 0 },
        { time: "6PM", icon: <Sun className="w-4 h-4 text-yellow-500" />, temp: 78, aqi: 90, precipitation: 0 },
        { time: "9PM", icon: <Sun className="w-4 h-4 text-yellow-500" />, temp: 72, aqi: 87, precipitation: 0 }
      ],
      alerts: [
        {
          type: "Heat Advisory",
          message: "High temperatures expected. Stay hydrated and limit outdoor activities.",
          color: "bg-orange-500"
        }
      ]
    }
  ];

  const currentDay = weeklyDetails[currentDayIndex];

  const navigateDay = (direction: 'prev' | 'next') => {
    if (direction === 'prev' && currentDayIndex > 0) {
      setCurrentDayIndex(currentDayIndex - 1);
    } else if (direction === 'next' && currentDayIndex < weeklyDetails.length - 1) {
      setCurrentDayIndex(currentDayIndex + 1);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-blue-500 px-4 py-3 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onNavigate('home')}
              className="text-white hover:bg-white/20 p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-lg font-medium">Daily Forecast</h1>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/20 p-2"
          >
            <MoreVertical className="w-5 h-5" />
          </Button>
        </div>
      </div>

      {/* Day Navigation */}
      <div className="bg-card border-b border-border px-4 py-3">
        <div className="flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigateDay('prev')}
            disabled={currentDayIndex === 0}
            className="p-2"
          >
            <ChevronLeft className="w-5 h-5" />
          </Button>
          
          <div className="text-center">
            <div className="text-lg font-medium text-foreground">
              {currentDay.day}
            </div>
            <div className="text-sm text-muted-foreground">
              {currentDay.date}
            </div>
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigateDay('next')}
            disabled={currentDayIndex === weeklyDetails.length - 1}
            className="p-2"
          >
            <ChevronRight className="w-5 h-5" />
          </Button>
        </div>
      </div>

      {/* Day Dots Indicator */}
      <div className="flex justify-center gap-2 py-3 bg-card border-b border-border">
        {weeklyDetails.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentDayIndex(index)}
            className={`w-2 h-2 rounded-full transition-colors ${
              index === currentDayIndex ? 'bg-blue-500' : 'bg-gray-300'
            }`}
          />
        ))}
      </div>

      <div className="px-4 pt-4 pb-24 space-y-4">
        {/* Main Weather Card */}
        <Card className="p-6 bg-gradient-to-br from-blue-500 to-blue-600 text-white relative overflow-hidden">
          <div className="absolute top-4 right-4 opacity-30">
            {currentDay.weather.icon}
          </div>
          
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-4xl font-bold">{currentDay.weather.temp}°F</span>
              {currentDay.isToday && (
                <Badge className="bg-white/20 text-white">Now</Badge>
              )}
              {currentDay.isPast && (
                <Badge className="bg-white/20 text-white">Past</Badge>
              )}
            </div>
            
            <div className="mb-4">
              <span className="text-lg text-blue-100">{currentDay.weather.condition}</span>
            </div>
            
            <div className="flex items-center gap-4 mb-4">
              <span className="text-blue-100">🔺 {currentDay.weather.high}°F</span>
              <span className="text-blue-100">🔻 {currentDay.weather.low}°F</span>
              <span className="text-blue-100">Feels like {currentDay.weather.feelsLike}°F</span>
            </div>
          </div>
        </Card>

        {/* Alerts */}
        {currentDay.alerts.length > 0 && (
          <div className="space-y-2">
            {currentDay.alerts.map((alert, index) => (
              <Card key={index} className={`p-4 ${alert.color.replace('bg-', 'bg-')}/10 border-l-4 border-${alert.color.replace('bg-', '')}-500`}>
                <div className="flex items-start gap-3">
                  <AlertTriangle className={`w-5 h-5 ${alert.color.replace('bg-', 'text-')}-600 flex-shrink-0 mt-0.5`} />
                  <div className="flex-1">
                    <h3 className={`font-medium ${alert.color.replace('bg-', 'text-')}-800 mb-1`}>{alert.type}</h3>
                    <p className={`text-sm ${alert.color.replace('bg-', 'text-')}-700`}>{alert.message}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* Air Quality */}
        <Card className="p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-medium text-foreground">Air Quality</h3>
            <Badge className={`${currentDay.airQuality.color} text-white`}>
              {currentDay.airQuality.level}
            </Badge>
          </div>
          
          <div className="flex items-center gap-4 mb-4">
            <div className="text-3xl font-light text-foreground">{currentDay.airQuality.aqi}</div>
            <div className="flex-1">
              <p className="text-sm text-muted-foreground mb-2">{currentDay.airQuality.description}</p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-orange-400"></div>
                <span className="text-muted-foreground">PM2.5</span>
              </div>
              <span className="font-medium text-foreground">{currentDay.airQuality.pm25} μg/m³</span>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
                <span className="text-muted-foreground">PM10</span>
              </div>
              <span className="font-medium text-foreground">{currentDay.airQuality.pm10} μg/m³</span>
            </div>
          </div>
        </Card>

        {/* Recommendations */}
        <Card className="p-4">
          <h3 className="font-medium text-foreground mb-3">Health Recommendations</h3>
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <Shirt className="w-4 h-4 text-blue-600" />
              </div>
              <div>
                <div className="font-medium text-foreground">Face Mask</div>
                <div className="text-sm text-muted-foreground">{currentDay.recommendations.mask}</div>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                <Sun className="w-4 h-4 text-green-600" />
              </div>
              <div>
                <div className="font-medium text-foreground">Activity</div>
                <div className="text-sm text-muted-foreground">{currentDay.recommendations.activity}</div>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                <Thermometer className="w-4 h-4 text-purple-600" />
              </div>
              <div>
                <div className="font-medium text-gray-900">Clothing</div>
                <div className="text-sm text-gray-600">{currentDay.recommendations.clothing}</div>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-pink-100 rounded-full flex items-center justify-center flex-shrink-0">
                <Heart className="w-4 h-4 text-pink-600" />
              </div>
              <div>
                <div className="font-medium text-gray-900">Skincare</div>
                <div className="text-sm text-gray-600">{currentDay.recommendations.skincare}</div>
              </div>
            </div>
          </div>
        </Card>

        {/* Hourly Forecast */}
        <Card className="p-4">
          <h3 className="font-medium text-gray-900 mb-4">Hourly Forecast</h3>
          <div className="overflow-x-auto scrollbar-hide">
            <div className="flex gap-4 pb-2" style={{ width: 'max-content' }}>
              {currentDay.hourlyForecast.map((hour, index) => (
                <div key={index} className="text-center flex-shrink-0 w-20 p-2 bg-gray-50 rounded-lg">
                  <div className="text-xs text-gray-600 mb-2">{hour.time}</div>
                  <div className="mb-2 flex justify-center">{hour.icon}</div>
                  <div className="text-sm font-medium text-gray-900 mb-1">{hour.temp}°</div>
                  <div className="text-xs text-gray-500 mb-1">AQI {hour.aqi}</div>
                  {hour.precipitation > 0 && (
                    <div className="text-xs text-blue-600">{hour.precipitation}%</div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Detailed Metrics */}
        <Card className="p-4">
          <h3 className="font-medium text-gray-900 mb-4">Detailed Metrics</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center gap-3">
              <Wind className="w-5 h-5 text-blue-500" />
              <div>
                <div className="text-sm text-gray-600">Wind</div>
                <div className="font-medium text-gray-900">{currentDay.weather.windSpeed} mph {currentDay.weather.windDirection}</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <Droplet className="w-5 h-5 text-blue-500" />
              <div>
                <div className="text-sm text-gray-600">Humidity</div>
                <div className="font-medium text-gray-900">{currentDay.weather.humidity}%</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <Eye className="w-5 h-5 text-blue-500" />
              <div>
                <div className="text-sm text-gray-600">Visibility</div>
                <div className="font-medium text-gray-900">{currentDay.weather.visibility} mi</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <Gauge className="w-5 h-5 text-blue-500" />
              <div>
                <div className="text-sm text-gray-600">Pressure</div>
                <div className="font-medium text-gray-900">{currentDay.weather.pressure} hPa</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <Sun className="w-5 h-5 text-yellow-500" />
              <div>
                <div className="text-sm text-gray-600">UV Index</div>
                <div className="font-medium text-gray-900">{currentDay.weather.uvIndex}</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <Umbrella className="w-5 h-5 text-blue-500" />
              <div>
                <div className="text-sm text-gray-600">Precipitation</div>
                <div className="font-medium text-gray-900">{currentDay.weather.precipitation}%</div>
              </div>
            </div>
          </div>
        </Card>
      </div>

      <BottomNavigation 
        activeTab="forecast" 
        onTabChange={(tab) => {
          const screenMap: { [key: string]: string } = {
            'home': 'home',
            'map': 'parks',
            'alerts': 'alerts',
            'forecast': 'forecast',
            'settings': 'settings'
          };
          if (screenMap[tab]) {
            onNavigate(screenMap[tab]);
          }
        }} 
      />
    </div>
  );
}