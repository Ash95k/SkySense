import { useState } from 'react';
import { Plus, Minus, MapPin, Navigation, Search } from 'lucide-react';
import { Button } from './ui/button';

interface InteractiveMapProps {
  onLocationSelect?: (location: { lat: number; lng: number; name: string }) => void;
  markers?: Array<{
    id: string;
    lat: number;
    lng: number;
    name: string;
    type: 'park' | 'station' | 'hospital' | 'school';
    aqi?: number;
  }>;
  height?: string;
  showControls?: boolean;
}

export function InteractiveMap({ 
  onLocationSelect, 
  markers = [], 
  height = "h-full", 
  showControls = true 
}: InteractiveMapProps) {
  const [zoom, setZoom] = useState(15);
  const [selectedMarker, setSelectedMarker] = useState<string | null>(null);

  const handleZoomIn = () => {
    setZoom(prev => Math.min(prev + 1, 20));
  };

  const handleZoomOut = () => {
    setZoom(prev => Math.max(prev - 1, 10));
  };

  const handleMapClick = (event: React.MouseEvent<SVGElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    
    if (onLocationSelect) {
      onLocationSelect({
        lat: 40.7128 + (y - 150) * 0.001,
        lng: -74.0060 + (x - 200) * 0.001,
        name: `Location (${Math.round(x)}, ${Math.round(y)})`
      });
    }
  };

  return (
    <div className={`relative ${height} w-full overflow-hidden rounded-lg bg-gray-100`}>
      {/* Map Container */}
      <div className="absolute inset-0">
        <svg 
          className="w-full h-full cursor-crosshair" 
          viewBox="0 0 400 300"
          onClick={handleMapClick}
        >
          {/* Background - Light green terrain */}
          <rect width="100%" height="100%" fill="#e8f5e8" />
          
          {/* Terrain patterns */}
          <defs>
            <pattern id="terrain" width="20" height="20" patternUnits="userSpaceOnUse">
              <circle cx="10" cy="10" r="1" fill="#d4edda" opacity="0.3"/>
              <circle cx="5" cy="5" r="0.5" fill="#c3e6cb" opacity="0.2"/>
              <circle cx="15" cy="15" r="0.5" fill="#c3e6cb" opacity="0.2"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#terrain)" />
          
          {/* Water bodies - Blue lake/river */}
          <path 
            d="M50,120 Q80,110 120,115 Q160,120 200,115 Q240,110 280,115 Q320,120 350,115 L350,160 Q320,165 280,160 Q240,165 200,160 Q160,165 120,160 Q80,165 50,160 Z" 
            fill="#87ceeb" 
            opacity="0.8"
          />
          
          {/* Additional smaller water body */}
          <ellipse cx="300" cy="60" rx="35" ry="20" fill="#87ceeb" opacity="0.7" />
          
          {/* Forested areas - Dark green */}
          <g fill="#228B22" opacity="0.6">
            {/* Trees scattered around */}
            <circle cx="80" cy="50" r="12" />
            <circle cx="95" cy="45" r="8" />
            <circle cx="110" cy="55" r="10" />
            <circle cx="85" cy="65" r="6" />
            
            <circle cx="280" cy="80" r="15" />
            <circle cx="295" cy="75" r="10" />
            <circle cx="310" cy="85" r="8" />
            <circle cx="275" cy="95" r="12" />
            
            <circle cx="150" cy="200" r="14" />
            <circle cx="165" cy="195" r="9" />
            <circle cx="180" cy="205" r="11" />
            <circle cx="135" cy="210" r="7" />
            
            <circle cx="320" cy="180" r="13" />
            <circle cx="335" cy="175" r="9" />
            <circle cx="350" cy="185" r="10" />
            
            <circle cx="60" cy="220" r="16" />
            <circle cx="75" cy="215" r="11" />
            <circle cx="90" cy="225" r="8" />
            <circle cx="45" cy="235" r="10" />
          </g>
          
          {/* Roads - Light gray/white */}
          <g stroke="#ffffff" strokeWidth="3" opacity="0.9" fill="none">
            <path d="M0,140 Q100,135 200,140 Q300,145 400,140" />
            <path d="M180,0 Q185,100 180,200 Q175,250 180,300" />
            <path d="M0,200 Q100,195 200,200 Q300,205 400,200" />
            <path d="M120,0 Q125,150 120,300" />
            <path d="M280,0 Q285,150 280,300" />
          </g>
          
          {/* Smaller paths */}
          <g stroke="#ffffff" strokeWidth="2" opacity="0.7" fill="none">
            <path d="M0,80 L400,80" />
            <path d="M0,260 L400,260" />
            <path d="M60,0 L60,300" />
            <path d="M340,0 L340,300" />
          </g>
          
          {/* Park markers - Red location pins */}
          {markers.map((marker, index) => {
            // Position markers at realistic locations
            const positions = [
              { x: 80, y: 50 },   // Near forest area
              { x: 280, y: 80 },  // Near forest area
              { x: 150, y: 200 }, // Near forest area
              { x: 320, y: 180 }, // Near forest area
              { x: 60, y: 220 }   // Near forest area
            ];
            
            const pos = positions[index] || { x: 200, y: 150 };
            
            return (
              <g key={marker.id}>
                {/* Red location pin */}
                <path
                  d={`M${pos.x},${pos.y-10} C${pos.x-5},${pos.y-15} ${pos.x-5},${pos.y-20} ${pos.x},${pos.y-20} C${pos.x+5},${pos.y-20} ${pos.x+5},${pos.y-15} ${pos.x},${pos.y-10} Z`}
                  fill="#dc2626"
                  stroke="#ffffff"
                  strokeWidth="1"
                  className="cursor-pointer hover:scale-110 transition-transform"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedMarker(marker.id);
                  }}
                />
                <circle
                  cx={pos.x}
                  cy={pos.y - 15}
                  r="3"
                  fill="#ffffff"
                />
              </g>
            );
          })}
          
          {/* Buildings/Urban areas */}
          <g fill="#d1d5db" stroke="#9ca3af" strokeWidth="0.5">
            <rect x="20" y="20" width="15" height="20" />
            <rect x="40" y="15" width="12" height="25" />
            <rect x="55" y="22" width="18" height="18" />
            
            <rect x="190" y="25" width="20" height="15" />
            <rect x="215" y="20" width="15" height="20" />
            <rect x="235" y="25" width="18" height="15" />
            
            <rect x="360" y="20" width="16" height="22" />
            <rect x="380" y="18" width="14" height="24" />
            
            <rect x="25" y="250" width="18" height="16" />
            <rect x="45" y="245" width="15" height="21" />
            <rect x="65" y="250" width="20" height="16" />
            
            <rect x="300" y="250" width="22" height="18" />
            <rect x="325" y="245" width="16" height="23" />
            <rect x="345" y="250" width="18" height="18" />
          </g>
          
          {/* Compass */}
          <g transform="translate(370, 30)">
            <circle cx="0" cy="0" r="10" fill="#ffffff" stroke="#d1d5db" strokeWidth="1" opacity="0.9" />
            <path d="M0,-6 L3,0 L0,6 L-3,0 Z" fill="#dc2626" />
            <text x="0" y="16" textAnchor="middle" fontSize="6" fill="#6b7280">N</text>
          </g>
        </svg>
      </div>

      {/* Controls */}
      {showControls && (
        <div className="absolute right-4 top-4 z-10 flex flex-col gap-2">
          {/* My Location */}
          <Button
            variant="secondary"
            size="icon"
            className="bg-white hover:bg-gray-50 shadow-md w-8 h-8"
          >
            <Navigation className="w-4 h-4" />
          </Button>
          
          {/* Zoom Controls */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleZoomIn}
              className="block w-8 h-8 rounded-none hover:bg-gray-50"
            >
              <Plus className="w-4 h-4" />
            </Button>
            <div className="border-t border-gray-200" />
            <Button
              variant="ghost"
              size="icon"
              onClick={handleZoomOut}
              className="block w-8 h-8 rounded-none hover:bg-gray-50"
            >
              <Minus className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}