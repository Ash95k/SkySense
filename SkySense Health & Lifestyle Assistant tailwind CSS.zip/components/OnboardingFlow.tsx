import { useState } from 'react';
import { ChevronRight, CloudSun, Shield, AlertTriangle, Activity } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';

interface OnboardingProps {
  onComplete: () => void;
}

interface OnboardingStep {
  icon: React.ReactNode;
  title: string;
  description: string;
  color: string;
}

export function OnboardingFlow({ onComplete }: OnboardingProps) {
  const [currentStep, setCurrentStep] = useState(0);

  const steps: OnboardingStep[] = [
    {
      icon: <CloudSun className="w-16 h-16" />,
      title: "Track Real-Time Weather & Air Quality",
      description: "Get live updates on temperature, humidity, air quality index, and pollution levels in your area.",
      color: "text-blue-500"
    },
    {
      icon: <Shield className="w-16 h-16" />,
      title: "Receive Health-Based Alerts",
      description: "Personalized notifications based on your health conditions like asthma, allergies, and sensitivities.",
      color: "text-green-500"
    },
    {
      icon: <Activity className="w-16 h-16" />,
      title: "Smart Suggestions",
      description: "Get recommendations for masks, clothing, and optimal outdoor activity times based on current conditions.",
      color: "text-purple-500"
    },
    {
      icon: <AlertTriangle className="w-16 h-16" />,
      title: "Safety Alerts During Disasters",
      description: "Receive emergency notifications for natural disasters with safety tips and shelter information.",
      color: "text-red-500"
    }
  ];

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
    }
  };

  const skipToEnd = () => {
    onComplete();
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="flex justify-between items-center p-4">
        <div className="flex space-x-2">
          {steps.map((_, index) => (
            <div
              key={index}
              className={`w-2 h-2 rounded-full transition-colors ${
                index <= currentStep ? 'bg-blue-500' : 'bg-gray-300'
              }`}
            />
          ))}
        </div>
        <Button variant="ghost" onClick={skipToEnd} className="text-muted-foreground">
          Skip
        </Button>
      </div>

      {/* Content */}
      <div className="flex-1 flex items-center justify-center px-6">
        <Card className="w-full max-w-sm p-8 text-center border-0 shadow-none">
          <div className={`mb-8 ${steps[currentStep].color} flex justify-center`}>
            {steps[currentStep].icon}
          </div>
          
          <h2 className="text-xl font-medium text-foreground mb-4">
            {steps[currentStep].title}
          </h2>
          
          <p className="text-muted-foreground leading-relaxed">
            {steps[currentStep].description}
          </p>
        </Card>
      </div>

      {/* Footer */}
      <div className="p-6 pb-20">
        <Button 
          onClick={nextStep}
          className="w-full"
          size="lg"
        >
          {currentStep === steps.length - 1 ? 'Get Started' : 'Next'}
          <ChevronRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}