import { useState } from 'react';
import { ArrowLeft, Leaf, Car, Bike, Award, TrendingUp, Target } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { BottomNavigation } from './BottomNavigation';

interface EcoScoreScreenProps {
  onNavigate: (screen: string) => void;
}

interface EcoAction {
  id: string;
  title: string;
  description: string;
  impact: string;
  category: 'transport' | 'energy' | 'lifestyle';
  completed: boolean;
  carbonSaved: number; // kg CO2
}

export function EcoScoreScreen({ onNavigate }: EcoScoreScreenProps) {
  const [selectedPeriod, setSelectedPeriod] = useState<'week' | 'month' | 'year'>('week');

  // Mock user eco data
  const ecoData = {
    totalScore: 76,
    carbonSaved: 4.2, // kg CO2 this week
    weeklyGoal: 5.0,
    rank: 'Eco Warrior',
    streak: 7,
    totalActions: 23
  };

  const weeklyBreakdown = [
    { day: 'Mon', score: 85, actions: 3 },
    { day: 'Tue', score: 72, actions: 2 },
    { day: 'Wed', score: 90, actions: 4 },
    { day: 'Thu', score: 68, actions: 2 },
    { day: 'Fri', score: 78, actions: 3 },
    { day: 'Sat', score: 82, actions: 3 },
    { day: 'Sun', score: 76, actions: 2 }
  ];

  const ecoActions: EcoAction[] = [
    {
      id: '1',
      title: 'Bike to work today',
      description: 'Air quality is good - perfect for cycling!',
      impact: 'High impact',
      category: 'transport',
      completed: false,
      carbonSaved: 2.1
    },
    {
      id: '2',
      title: 'Use public transport',
      description: 'Reduce emissions by taking the bus or subway',
      impact: 'Medium impact',
      category: 'transport',
      completed: true,
      carbonSaved: 1.5
    },
    {
      id: '3',
      title: 'Air purifying plants',
      description: 'Add plants to improve indoor air quality',
      impact: 'Low impact',
      category: 'lifestyle',
      completed: false,
      carbonSaved: 0.3
    },
    {
      id: '4',
      title: 'Energy-efficient AC',
      description: 'Use AC wisely during high AQI days',
      impact: 'Medium impact',
      category: 'energy',
      completed: true,
      carbonSaved: 1.2
    }
  ];

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'transport': return <Car className="w-4 h-4" />;
      case 'energy': return <Target className="w-4 h-4" />;
      case 'lifestyle': return <Leaf className="w-4 h-4" />;
      default: return <Leaf className="w-4 h-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'transport': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'energy': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'lifestyle': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'High impact': return 'text-green-600 bg-green-50';
      case 'Medium impact': return 'text-orange-600 bg-orange-50';
      case 'Low impact': return 'text-gray-600 bg-gray-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-blue-500 px-4 py-3 text-white">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onNavigate('home')}
            className="text-white hover:bg-white/20 p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-medium">Eco Score</h1>
        </div>
      </div>

      <div className="p-4 pb-20 space-y-4">
        {/* Eco Score Summary */}
        <Card className="p-6 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-950/20 dark:to-blue-950/20 border-green-200 dark:border-green-800">
          <div className="text-center">
            <div className="w-20 h-20 mx-auto mb-4 bg-green-500 rounded-full flex items-center justify-center">
              <div className="text-center text-white">
                <div className="text-2xl font-light">{ecoData.totalScore}</div>
                <div className="text-xs">ECO</div>
              </div>
            </div>
            <h2 className="text-xl font-medium text-foreground mb-1">{ecoData.rank}</h2>
            <p className="text-sm text-muted-foreground mb-4">
              {ecoData.streak} day streak • {ecoData.totalActions} total actions
            </p>

            <div className="flex items-center justify-center gap-6 text-sm">
              <div className="text-center">
                <div className="font-medium text-green-600">{ecoData.carbonSaved}kg</div>
                <div className="text-muted-foreground">CO₂ saved</div>
              </div>
              <div className="text-center">
                <div className="font-medium text-blue-600">{ecoData.weeklyGoal}kg</div>
                <div className="text-muted-foreground">Weekly goal</div>
              </div>
            </div>

            <div className="mt-4">
              <div className="flex justify-between text-sm mb-2">
                <span className="text-muted-foreground">Weekly progress</span>
                <span className="text-muted-foreground">{Math.round((ecoData.carbonSaved / ecoData.weeklyGoal) * 100)}%</span>
              </div>
              <Progress value={(ecoData.carbonSaved / ecoData.weeklyGoal) * 100} className="h-2" />
            </div>
          </div>
        </Card>

        {/* Period Toggle */}
        <div className="flex bg-gray-100 dark:bg-gray-800 rounded-lg p-1">
          {['week', 'month', 'year'].map((period) => (
            <Button
              key={period}
              variant={selectedPeriod === period ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setSelectedPeriod(period as any)}
              className={`flex-1 ${selectedPeriod === period ? 'bg-green-500 text-white' : 'text-gray-600 dark:text-gray-300'}`}
            >
              {period.charAt(0).toUpperCase() + period.slice(1)}
            </Button>
          ))}
        </div>

        {/* Weekly Breakdown */}
        <Card className="p-4">
          <h3 className="font-medium text-foreground mb-4">This Week</h3>
          <div className="space-y-3">
            {weeklyBreakdown.map((day, index) => (
              <div key={index} className="flex items-center gap-4">
                <div className="w-8 text-sm text-muted-foreground">{day.day}</div>
                <div className="flex-1">
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="text-foreground">Score: {day.score}</span>
                    <span className="text-muted-foreground">{day.actions} actions</span>
                  </div>
                  <Progress value={day.score} className="h-2" />
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Recommended Actions */}
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-4">
            <Target className="w-5 h-5 text-green-500" />
            <h3 className="font-medium text-foreground">Recommended Actions</h3>
          </div>
          
          <div className="space-y-3">
            {ecoActions.map((action) => (
              <div key={action.id} className={`p-3 rounded-lg border ${action.completed ? 'bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800' : 'bg-card border-border'}`}>
                <div className="flex items-start gap-3">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-1 ${action.completed ? 'bg-green-500' : 'bg-gray-200 dark:bg-gray-700'}`}>
                    {action.completed ? (
                      <span className="text-white text-xs">✓</span>
                    ) : (
                      getCategoryIcon(action.category)
                    )}
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className={`font-medium ${action.completed ? 'text-green-800 dark:text-green-200' : 'text-foreground'}`}>
                        {action.title}
                      </h4>
                      <Badge variant="outline" className={getCategoryColor(action.category)}>
                        {action.category}
                      </Badge>
                    </div>
                    
                    <p className={`text-sm mb-2 ${action.completed ? 'text-green-700 dark:text-green-300' : 'text-muted-foreground'}`}>
                      {action.description}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Badge variant="outline" className={getImpactColor(action.impact)}>
                          {action.impact}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {action.carbonSaved}kg CO₂ saved
                        </span>
                      </div>
                      
                      {!action.completed && (
                        <Button size="sm" className="bg-green-500 hover:bg-green-600 text-white">
                          Complete
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Impact Stats */}
        <Card className="p-4 bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800">
          <div className="flex items-center gap-2 mb-3">
            <Award className="w-5 h-5 text-blue-500" />
            <h3 className="font-medium text-blue-900 dark:text-blue-100">Your Impact</h3>
          </div>
          
          <div className="grid grid-cols-2 gap-4 text-center">
            <div>
              <div className="text-lg font-medium text-blue-900 dark:text-blue-100">18.5kg</div>
              <div className="text-xs text-blue-800 dark:text-blue-200">Total CO₂ saved</div>
            </div>
            <div>
              <div className="text-lg font-medium text-blue-900 dark:text-blue-100">142</div>
              <div className="text-xs text-blue-800 dark:text-blue-200">Miles biked</div>
            </div>
            <div>
              <div className="text-lg font-medium text-blue-900 dark:text-blue-100">8</div>
              <div className="text-xs text-blue-800 dark:text-blue-200">Clean air days</div>
            </div>
            <div>
              <div className="text-lg font-medium text-blue-900 dark:text-blue-100">23</div>
              <div className="text-xs text-blue-800 dark:text-blue-200">Actions taken</div>
            </div>
          </div>
        </Card>
      </div>

      <BottomNavigation 
        activeTab="home" 
        onTabChange={(tab) => {
          const screenMap: { [key: string]: string } = {
            'home': 'home',
            'map': 'parks',
            'alerts': 'alerts',
            'forecast': 'forecast',
            'settings': 'settings'
          };
          if (screenMap[tab]) {
            onNavigate(screenMap[tab]);
          }
        }} 
      />
    </div>
  );
}