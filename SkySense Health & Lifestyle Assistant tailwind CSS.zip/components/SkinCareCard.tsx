import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Heart, Sun, Droplet, Wind, Thermometer, Sparkles } from 'lucide-react';

interface SkinCareCardProps {
  className?: string;
}

export function SkinCareCard({ className = '' }: SkinCareCardProps) {
  // Mock weather data - in real app this would come from API
  const weatherData = {
    humidity: 42,
    uvIndex: 7,
    temperature: 68,
    windSpeed: 8,
    aqi: 87,
    precipitation: 0
  };

  const getSkinCareRecommendations = () => {
    const recommendations = [];

    // UV Protection
    if (weatherData.uvIndex >= 6) {
      recommendations.push({
        priority: 'high',
        icon: <Sun className="w-4 h-4 text-orange-600" />,
        title: 'UV Protection Critical',
        advice: `UV Index ${weatherData.uvIndex} - Apply SPF 50+ broad-spectrum sunscreen every 2 hours`,
        category: 'sun protection'
      });
    } else if (weatherData.uvIndex >= 3) {
      recommendations.push({
        priority: 'medium',
        icon: <Sun className="w-4 h-4 text-yellow-600" />,
        title: 'Sun Protection',
        advice: `UV Index ${weatherData.uvIndex} - Use SPF 30+ sunscreen`,
        category: 'sun protection'
      });
    }

    // Humidity-based care
    if (weatherData.humidity < 40) {
      recommendations.push({
        priority: 'high',
        icon: <Droplet className="w-4 h-4 text-blue-600" />,
        title: 'Hydration Essential',
        advice: `Very low humidity (${weatherData.humidity}%) - Use thick moisturizer and hydrating serum`,
        category: 'moisturizing'
      });
    } else if (weatherData.humidity < 60) {
      recommendations.push({
        priority: 'medium',
        icon: <Droplet className="w-4 h-4 text-blue-500" />,
        title: 'Extra Moisture Needed',
        advice: `Low humidity (${weatherData.humidity}%) - Apply moisturizer more frequently`,
        category: 'moisturizing'
      });
    } else if (weatherData.humidity > 80) {
      recommendations.push({
        priority: 'medium',
        icon: <Sparkles className="w-4 h-4 text-purple-600" />,
        title: 'Oil Control',
        advice: `High humidity (${weatherData.humidity}%) - Use lightweight, oil-free products`,
        category: 'oil control'
      });
    }

    // Temperature-based care
    if (weatherData.temperature > 75) {
      recommendations.push({
        priority: 'medium',
        icon: <Thermometer className="w-4 h-4 text-red-500" />,
        title: 'Heat Protection',
        advice: `High temperature (${weatherData.temperature}°F) - Use cooling gel moisturizer and stay hydrated`,
        category: 'temperature care'
      });
    } else if (weatherData.temperature < 50) {
      recommendations.push({
        priority: 'medium',
        icon: <Thermometer className="w-4 h-4 text-blue-500" />,
        title: 'Cold Weather Care',
        advice: `Cold temperature (${weatherData.temperature}°F) - Use rich, protective cream`,
        category: 'temperature care'
      });
    }

    // Wind protection
    if (weatherData.windSpeed > 10) {
      recommendations.push({
        priority: 'medium',
        icon: <Wind className="w-4 h-4 text-gray-600" />,
        title: 'Wind Protection',
        advice: `Windy conditions (${weatherData.windSpeed} mph) - Use protective barrier cream`,
        category: 'environmental protection'
      });
    }

    // Air quality impact
    if (weatherData.aqi > 100) {
      recommendations.push({
        priority: 'high',
        icon: <Heart className="w-4 h-4 text-purple-600" />,
        title: 'Pollution Protection',
        advice: `High AQI (${weatherData.aqi}) - Use antioxidant serum and gentle cleanser`,
        category: 'pollution protection'
      });
    } else if (weatherData.aqi > 50) {
      recommendations.push({
        priority: 'medium',
        icon: <Heart className="w-4 h-4 text-purple-500" />,
        title: 'Antioxidant Care',
        advice: `Moderate AQI (${weatherData.aqi}) - Consider antioxidant skincare products`,
        category: 'pollution protection'
      });
    }

    return recommendations.slice(0, 3); // Show top 3 recommendations
  };

  const recommendations = getSkinCareRecommendations();
  const highPriorityCount = recommendations.filter(r => r.priority === 'high').length;

  return (
    <Card className={`p-4 bg-gradient-to-br from-pink-50 to-purple-50 dark:from-pink-950/20 dark:to-purple-950/20 border-pink-200 dark:border-pink-800 ${className}`}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Heart className="w-5 h-5 text-pink-600" />
          <h3 className="font-medium text-foreground">Skincare Weather Guide</h3>
        </div>
        {highPriorityCount > 0 && (
          <Badge className="bg-orange-100 text-orange-800 border-orange-300 dark:bg-orange-900/40 dark:text-orange-300">
            {highPriorityCount} urgent
          </Badge>
        )}
      </div>

      <div className="space-y-3">
        {recommendations.map((rec, index) => (
          <div 
            key={index} 
            className={`p-3 rounded-lg border-l-4 ${
              rec.priority === 'high' 
                ? 'bg-orange-50 dark:bg-orange-950/20 border-l-orange-500' 
                : 'bg-blue-50 dark:bg-blue-950/20 border-l-blue-500'
            }`}
          >
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 mt-0.5">
                {rec.icon}
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-medium text-foreground text-sm mb-1">{rec.title}</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">{rec.advice}</p>
                <Badge 
                  variant="outline" 
                  className="mt-2 text-xs"
                >
                  {rec.category}
                </Badge>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 p-3 bg-white/50 dark:bg-gray-800/30 rounded-lg">
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="w-4 h-4 text-purple-600" />
          <span className="text-sm font-medium text-foreground">Today's Skin Summary</span>
        </div>
        <p className="text-xs text-muted-foreground">
          Current conditions: {weatherData.humidity}% humidity, UV Index {weatherData.uvIndex}, AQI {weatherData.aqi}. 
          {highPriorityCount > 0 ? ' Extra care needed today!' : ' Standard routine should suffice.'}
        </p>
      </div>
    </Card>
  );
}