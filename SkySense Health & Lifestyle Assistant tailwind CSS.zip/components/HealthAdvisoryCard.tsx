import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { AlertTriangle, Activity, Heart, Sun, Sparkles, Flower } from 'lucide-react';

interface UserProfile {
  hasAsthma: boolean;
  hasDustAllergy: boolean;
  hasPollenAllergy: boolean;
  hasHeartCondition: boolean;
  hasUVSensitivity: boolean;
  gender: string;
  ageGroup: string;
}

interface HealthAdvisoryCardProps {
  userProfile: UserProfile;
}

export function HealthAdvisoryCard({ userProfile }: HealthAdvisoryCardProps) {
  // Mock AQI data - in real app this would come from API
  const currentAQI = 87;
  const uvIndex = 5;

  const getHealthAdvice = () => {
    const conditions = [];
    if (userProfile.hasAsthma) conditions.push('asthma');
    if (userProfile.hasDustAllergy) conditions.push('dust allergy');
    if (userProfile.hasPollenAllergy) conditions.push('pollen allergy');
    if (userProfile.hasHeartCondition) conditions.push('heart condition');
    if (userProfile.hasUVSensitivity) conditions.push('UV sensitivity');

    // Get current weather conditions for skincare advice
    const humidity = 42; // Current humidity
    const temperature = 68; // Current temperature

    if (conditions.length === 0) {
      return {
        message: `Air quality is moderate. Consider limiting prolonged outdoor activities. Skincare tip: Low humidity (${humidity}%) - use extra moisturizer today.`,
        severity: "moderate",
        icon: <AlertTriangle className="w-5 h-5 text-yellow-600" />
      };
    }

    if (userProfile.hasAsthma && currentAQI > 50) {
      return {
        message: `Based on your asthma condition and current AQI (${currentAQI}), consider limiting outdoor activities and carry your inhaler. Skincare: Use gentle, fragrance-free products to avoid skin irritation.`,
        severity: "high",
        icon: <Activity className="w-5 h-5 text-red-600" />
      };
    }

    if (userProfile.hasPollenAllergy && currentAQI > 30) {
      return {
        message: `Pollen levels may be elevated with current AQI (${currentAQI}). Consider wearing a mask and limiting outdoor exposure. Skincare: Cleanse face gently after outdoor exposure to remove pollen.`,
        severity: "moderate",
        icon: <Flower className="w-5 h-5 text-pink-600" />
      };
    }

    if (userProfile.hasUVSensitivity && uvIndex > 3) {
      return {
        message: `High UV levels detected (${uvIndex}). Use SPF 30+ sunscreen and wear protective clothing. Skincare essential: Reapply sunscreen every 2 hours and use moisturizer with antioxidants.`,
        severity: "moderate",
        icon: <Sun className="w-5 h-5 text-orange-600" />
      };
    }

    return {
      message: `Based on your health profile (${conditions.join(', ')}), current conditions are acceptable with precautions. Skincare tip: Current temperature (${temperature}°F) is comfortable - maintain your regular routine with adequate hydration.`,
      severity: "low",
      icon: <Heart className="w-5 h-5 text-green-600" />
    };
  };

  const advice = getHealthAdvice();
  const bgColor = advice.severity === 'high' ? 'bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-800' :
                  advice.severity === 'moderate' ? 'bg-orange-50 dark:bg-orange-950/20 border-orange-200 dark:border-orange-800' :
                  'bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800';

  return (
    <Card className={`p-4 ${bgColor}`}>
      <div className="flex items-start gap-3">
        <div className="flex-shrink-0 mt-0.5">
          {advice.icon}
        </div>
        
        <div className="flex-1">
          <h3 className="font-medium text-foreground mb-2">
            Health Advisory
          </h3>
          
          <p className="text-sm text-foreground/80 mb-3">
            {advice.message}
          </p>
          
          <div className="flex items-center gap-2">
            <Badge variant="outline" className={
              advice.severity === 'high' ? 'text-red-700 border-red-300 bg-red-100 dark:bg-red-900/40 dark:text-red-300' :
              advice.severity === 'moderate' ? 'text-orange-700 border-orange-300 bg-orange-100 dark:bg-orange-900/40 dark:text-orange-300' :
              'text-green-700 border-green-300 bg-green-100 dark:bg-green-900/40 dark:text-green-300'
            }>
              {advice.severity === 'high' ? 'High Risk' : 
               advice.severity === 'moderate' ? 'Moderate Risk' : 'Low Risk'}
            </Badge>
            <span className="text-xs text-muted-foreground">
              Updated 5 min ago
            </span>
          </div>
        </div>
      </div>
    </Card>
  );
}