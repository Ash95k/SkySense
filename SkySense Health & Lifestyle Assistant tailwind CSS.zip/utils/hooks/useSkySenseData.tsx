import { useState, useEffect, useCallback } from 'react';
import { api } from '../supabase/client';

// Custom hook for managing SkySense data
export function useSkySenseData(userId?: string) {
  const [weather, setWeather] = useState(null);
  const [airQuality, setAirQuality] = useState(null);
  const [parks, setParks] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [ecoScore, setEcoScore] = useState(null);
  const [badges, setBadges] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const location = 'San Francisco'; // Default location

  // Fetch weather data
  const fetchWeather = useCallback(async () => {
    try {
      const data = await api.getWeather(location);
      setWeather(data);
    } catch (err) {
      console.error('Failed to fetch weather:', err);
      setError(`Failed to fetch weather: ${err.message}`);
    }
  }, [location]);

  // Fetch air quality data
  const fetchAirQuality = useCallback(async () => {
    try {
      const data = await api.getAirQuality(location);
      setAirQuality(data);
    } catch (err) {
      console.error('Failed to fetch air quality:', err);
      setError(`Failed to fetch air quality: ${err.message}`);
    }
  }, [location]);

  // Fetch parks data
  const fetchParks = useCallback(async () => {
    try {
      const data = await api.getNearbyParks(location);
      setParks(data.parks || []);
    } catch (err) {
      console.error('Failed to fetch parks:', err);
      setError(`Failed to fetch parks: ${err.message}`);
    }
  }, [location]);

  // Fetch emergency alerts
  const fetchAlerts = useCallback(async () => {
    try {
      const data = await api.getEmergencyAlerts(location);
      setAlerts(data.alerts || []);
    } catch (err) {
      console.error('Failed to fetch alerts:', err);
      setError(`Failed to fetch alerts: ${err.message}`);
    }
  }, [location]);

  // Fetch user-specific data
  const fetchUserData = useCallback(async () => {
    if (!userId) return;
    
    try {
      // Fetch notifications
      const notificationsData = await api.getUserNotifications(userId);
      setNotifications(notificationsData.notifications || []);

      // Fetch eco score
      const ecoData = await api.getEcoScore(userId);
      setEcoScore(ecoData);

      // Fetch badges
      const badgesData = await api.getUserBadges(userId);
      setBadges(badgesData.badges || []);
    } catch (err) {
      console.error('Failed to fetch user data:', err);
      setError(`Failed to fetch user data: ${err.message}`);
    }
  }, [userId]);

  // Initial data fetch
  useEffect(() => {
    const fetchAllData = async () => {
      setLoading(true);
      setError(null);
      
      try {
        await Promise.all([
          fetchWeather(),
          fetchAirQuality(),
          fetchParks(),
          fetchAlerts(),
          fetchUserData(),
        ]);
      } catch (err) {
        console.error('Error fetching initial data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchAllData();
  }, [fetchWeather, fetchAirQuality, fetchParks, fetchAlerts, fetchUserData]);

  // Refresh functions
  const refreshWeather = useCallback(() => fetchWeather(), [fetchWeather]);
  const refreshAirQuality = useCallback(() => fetchAirQuality(), [fetchAirQuality]);
  const refreshParks = useCallback(() => fetchParks(), [fetchParks]);
  const refreshAlerts = useCallback(() => fetchAlerts(), [fetchAlerts]);
  const refreshUserData = useCallback(() => fetchUserData(), [fetchUserData]);

  // Action functions
  const recordEcoAction = useCallback(async (action: string, category: string, points?: number) => {
    if (!userId) return;
    
    try {
      const calculatedPoints = points || 10;
      await api.recordEcoAction({
        userId,
        action,
        category,
        points: calculatedPoints
      });
      
      // Refresh eco score
      await fetchUserData();
      
      return calculatedPoints;
    } catch (err) {
      console.error('Failed to record eco action:', err);
      throw err;
    }
  }, [userId, fetchUserData]);

  const submitCommunityReport = useCallback(async (report: any) => {
    try {
      const result = await api.submitCommunityReport({
        ...report,
        location
      });
      
      // Optionally refresh alerts or other data
      await refreshAlerts();
      
      return result;
    } catch (err) {
      console.error('Failed to submit community report:', err);
      throw err;
    }
  }, [location, refreshAlerts]);

  const markNotificationAsRead = useCallback(async (notificationId: string) => {
    try {
      await api.markNotificationAsRead(notificationId);
      
      // Update local state
      setNotifications(prev => 
        prev.map(notif => 
          notif.id === notificationId 
            ? { ...notif, read: true, readAt: new Date().toISOString() }
            : notif
        )
      );
    } catch (err) {
      console.error('Failed to mark notification as read:', err);
      throw err;
    }
  }, []);

  return {
    // Data
    weather,
    airQuality,
    parks,
    alerts,
    notifications,
    ecoScore,
    badges,
    loading,
    error,
    
    // Refresh functions
    refreshWeather,
    refreshAirQuality,
    refreshParks,
    refreshAlerts,
    refreshUserData,
    
    // Action functions
    recordEcoAction,
    submitCommunityReport,
    markNotificationAsRead,
    
    // Utility
    location
  };
}

// Hook for managing user profile
export function useUserProfile() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const saveProfile = useCallback(async (profileData: any) => {
    setLoading(true);
    setError(null);
    
    try {
      const result = await api.saveProfile(profileData);
      setProfile(profileData);
      
      // Store profile ID in localStorage for demo purposes
      if (result.profileId) {
        localStorage.setItem('skysense_profile_id', result.profileId);
      }
      
      return result;
    } catch (err) {
      console.error('Failed to save profile:', err);
      setError(`Failed to save profile: ${err.message}`);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const loadProfile = useCallback(async (profileId?: string) => {
    const id = profileId || localStorage.getItem('skysense_profile_id');
    if (!id) return;
    
    setLoading(true);
    setError(null);
    
    try {
      const result = await api.getProfile(id);
      setProfile(result.profile);
      return result.profile;
    } catch (err) {
      console.error('Failed to load profile:', err);
      setError(`Failed to load profile: ${err.message}`);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadProfile();
  }, [loadProfile]);

  return {
    profile,
    loading,
    error,
    saveProfile,
    loadProfile
  };
}

// Hook for real-time notifications
export function useNotifications(userId?: string) {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(false);

  const fetchNotifications = useCallback(async () => {
    if (!userId) return;
    
    setLoading(true);
    try {
      const data = await api.getUserNotifications(userId);
      setNotifications(data.notifications || []);
      setUnreadCount(data.notifications?.filter(n => !n.read).length || 0);
    } catch (err) {
      console.error('Failed to fetch notifications:', err);
    } finally {
      setLoading(false);
    }
  }, [userId]);

  const markAsRead = useCallback(async (notificationId: string) => {
    try {
      await api.markNotificationAsRead(notificationId);
      setNotifications(prev => 
        prev.map(notif => 
          notif.id === notificationId 
            ? { ...notif, read: true }
            : notif
        )
      );
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (err) {
      console.error('Failed to mark notification as read:', err);
    }
  }, []);

  useEffect(() => {
    fetchNotifications();
    
    // Set up polling for new notifications (every 30 seconds)
    const interval = setInterval(fetchNotifications, 30000);
    return () => clearInterval(interval);
  }, [fetchNotifications]);

  return {
    notifications,
    unreadCount,
    loading,
    refresh: fetchNotifications,
    markAsRead
  };
}