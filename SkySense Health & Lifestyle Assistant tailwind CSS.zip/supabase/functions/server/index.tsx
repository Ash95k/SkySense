import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Create Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '',
);

// Health check endpoint
app.get("/make-server-1ec076f3/health", (c) => {
  return c.json({ status: "ok", timestamp: new Date().toISOString() });
});

// User Profile Management
app.post("/make-server-1ec076f3/profile", async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    const accessToken = authHeader?.split(' ')[1];
    
    console.log('Profile save request - Auth header present:', !!authHeader);
    console.log('Access token extracted:', accessToken ? 'Yes' : 'No');
    
    // Check if this is the public anon key (for demo mode) or no auth
    const isAnonKey = accessToken === Deno.env.get('SUPABASE_ANON_KEY');
    const hasNoAuth = !accessToken || accessToken === 'null' || accessToken === 'undefined';
    
    if (isAnonKey || hasNoAuth) {
      // Allow anonymous profile storage for demo purposes
      console.log('Creating anonymous profile...');
      const profileData = await c.req.json();
      const profileId = `profile_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      await kv.set(`user_profile:${profileId}`, profileData);
      console.log('Anonymous profile created with ID:', profileId);
      return c.json({ success: true, profileId });
    }

    // Try to authenticate user with the provided token
    try {
      const { data: { user }, error } = await supabase.auth.getUser(accessToken);
      if (error) {
        console.log('Auth error:', error);
        // Fall back to anonymous profile creation
        const profileData = await c.req.json();
        const profileId = `profile_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        await kv.set(`user_profile:${profileId}`, profileData);
        console.log('Fallback anonymous profile created with ID:', profileId);
        return c.json({ success: true, profileId });
      }

      if (user) {
        console.log('Authenticated user profile creation for:', user.id);
        const profileData = await c.req.json();
        await kv.set(`user_profile:${user.id}`, profileData);
        return c.json({ success: true, userId: user.id, profileId: user.id });
      }
    } catch (authError) {
      console.log('Authentication failed, falling back to anonymous:', authError);
      // Fall back to anonymous profile creation
      const profileData = await c.req.json();
      const profileId = `profile_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      await kv.set(`user_profile:${profileId}`, profileData);
      console.log('Fallback anonymous profile created with ID:', profileId);
      return c.json({ success: true, profileId });
    }

    // If we get here, something went wrong
    return c.json({ error: 'Failed to create profile' }, 500);
  } catch (error) {
    console.log('Profile creation error:', error);
    return c.json({ error: 'Failed to save profile' }, 500);
  }
});

app.get("/make-server-1ec076f3/profile/:id", async (c) => {
  try {
    const profileId = c.req.param('id');
    const profile = await kv.get(`user_profile:${profileId}`);
    
    if (!profile) {
      return c.json({ error: 'Profile not found' }, 404);
    }
    
    return c.json({ profile });
  } catch (error) {
    console.log('Profile retrieval error:', error);
    return c.json({ error: 'Failed to get profile' }, 500);
  }
});

// Weather Data
app.get("/make-server-1ec076f3/weather/:location", async (c) => {
  try {
    const location = c.req.param('location');
    
    // Mock weather data - in production this would call a real weather API
    const weatherData = {
      location,
      current: {
        temperature: 24,
        condition: "Partly Cloudy",
        humidity: 42,
        windSpeed: 8,
        uvIndex: 7,
        precipitation: 0,
        pressure: 1013,
        visibility: 10
      },
      forecast: Array.from({ length: 7 }, (_, i) => ({
        date: new Date(Date.now() + i * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        high: 25 + Math.random() * 10,
        low: 15 + Math.random() * 8,
        condition: ["Sunny", "Cloudy", "Rainy", "Partly Cloudy"][Math.floor(Math.random() * 4)],
        humidity: 40 + Math.random() * 40,
        uvIndex: Math.floor(Math.random() * 11),
        precipitationChance: Math.floor(Math.random() * 100)
      })),
      aqi: {
        value: 87,
        category: "Moderate",
        pollutants: {
          pm25: 45,
          pm10: 65,
          o3: 78,
          no2: 23,
          so2: 12,
          co: 1.2
        }
      }
    };
    
    // Cache weather data for 10 minutes
    await kv.set(`weather:${location}`, weatherData, { ttl: 600 });
    
    return c.json(weatherData);
  } catch (error) {
    console.log('Weather data error:', error);
    return c.json({ error: 'Failed to get weather data' }, 500);
  }
});

// Air Quality Data
app.get("/make-server-1ec076f3/aqi/:location", async (c) => {
  try {
    const location = c.req.param('location');
    
    // Check cache first
    const cached = await kv.get(`aqi:${location}`);
    if (cached) {
      return c.json(cached);
    }
    
    // Mock AQI data - in production this would call a real AQI API
    const aqiData = {
      location,
      current: {
        aqi: 87,
        category: "Moderate",
        color: "#FFA500",
        healthAdvice: "Air quality is acceptable for most people. However, sensitive groups may experience minor to moderate symptoms from long-term exposure."
      },
      pollutants: {
        pm25: { value: 45, unit: "μg/m³" },
        pm10: { value: 65, unit: "μg/m³" },
        o3: { value: 78, unit: "μg/m³" },
        no2: { value: 23, unit: "μg/m³" },
        so2: { value: 12, unit: "μg/m³" },
        co: { value: 1.2, unit: "mg/m³" }
      },
      trends: Array.from({ length: 24 }, (_, i) => ({
        time: new Date(Date.now() - (23 - i) * 60 * 60 * 1000).toISOString(),
        aqi: 60 + Math.random() * 60
      }))
    };
    
    // Cache for 30 minutes
    await kv.set(`aqi:${location}`, aqiData, { ttl: 1800 });
    
    return c.json(aqiData);
  } catch (error) {
    console.log('AQI data error:', error);
    return c.json({ error: 'Failed to get AQI data' }, 500);
  }
});

// Community Reports
app.post("/make-server-1ec076f3/community/report", async (c) => {
  try {
    const reportData = await c.req.json();
    const reportId = `report_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const report = {
      ...reportData,
      id: reportId,
      timestamp: new Date().toISOString(),
      status: 'active',
      votes: { helpful: 0, notHelpful: 0 }
    };
    
    await kv.set(`community_report:${reportId}`, report);
    
    // Add to location-based reports
    const locationKey = `reports:${reportData.location || 'default'}`;
    const locationReports = await kv.get(locationKey) || [];
    locationReports.unshift(reportId);
    await kv.set(locationKey, locationReports.slice(0, 100)); // Keep last 100 reports
    
    return c.json({ success: true, reportId });
  } catch (error) {
    console.log('Community report error:', error);
    return c.json({ error: 'Failed to submit report' }, 500);
  }
});

app.get("/make-server-1ec076f3/community/reports/:location", async (c) => {
  try {
    const location = c.req.param('location');
    const locationKey = `reports:${location}`;
    const reportIds = await kv.get(locationKey) || [];
    
    const reports = [];
    for (const reportId of reportIds.slice(0, 20)) { // Get last 20 reports
      const report = await kv.get(`community_report:${reportId}`);
      if (report) {
        reports.push(report);
      }
    }
    
    return c.json({ reports });
  } catch (error) {
    console.log('Get reports error:', error);
    return c.json({ error: 'Failed to get reports' }, 500);
  }
});

// Eco Score Tracking
app.post("/make-server-1ec076f3/eco/action", async (c) => {
  try {
    const { userId, action, points, category } = await c.req.json();
    const actionId = `eco_action_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const ecoAction = {
      id: actionId,
      userId,
      action,
      points,
      category,
      timestamp: new Date().toISOString()
    };
    
    await kv.set(`eco_action:${actionId}`, ecoAction);
    
    // Update user's eco score
    const currentScore = await kv.get(`eco_score:${userId}`) || { total: 0, actions: [] };
    currentScore.total += points;
    currentScore.actions.unshift(actionId);
    currentScore.actions = currentScore.actions.slice(0, 100); // Keep last 100 actions
    
    await kv.set(`eco_score:${userId}`, currentScore);
    
    return c.json({ success: true, newTotal: currentScore.total });
  } catch (error) {
    console.log('Eco action error:', error);
    return c.json({ error: 'Failed to record eco action' }, 500);
  }
});

app.get("/make-server-1ec076f3/eco/score/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    const ecoScore = await kv.get(`eco_score:${userId}`) || { total: 0, actions: [] };
    
    // Get recent actions
    const recentActions = [];
    for (const actionId of ecoScore.actions.slice(0, 10)) {
      const action = await kv.get(`eco_action:${actionId}`);
      if (action) {
        recentActions.push(action);
      }
    }
    
    return c.json({
      total: ecoScore.total,
      recentActions,
      rank: Math.floor(ecoScore.total / 100) + 1 // Simple ranking system
    });
  } catch (error) {
    console.log('Get eco score error:', error);
    return c.json({ error: 'Failed to get eco score' }, 500);
  }
});

// Badges and Achievements
app.post("/make-server-1ec076f3/badges/unlock", async (c) => {
  try {
    const { userId, badgeType, criteria } = await c.req.json();
    const badgeId = `badge_${badgeType}_${Date.now()}`;
    
    const badge = {
      id: badgeId,
      userId,
      type: badgeType,
      criteria,
      unlockedAt: new Date().toISOString()
    };
    
    await kv.set(`user_badge:${badgeId}`, badge);
    
    // Add to user's badges
    const userBadges = await kv.get(`badges:${userId}`) || [];
    userBadges.push(badgeId);
    await kv.set(`badges:${userId}`, userBadges);
    
    return c.json({ success: true, badge });
  } catch (error) {
    console.log('Badge unlock error:', error);
    return c.json({ error: 'Failed to unlock badge' }, 500);
  }
});

app.get("/make-server-1ec076f3/badges/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    const badgeIds = await kv.get(`badges:${userId}`) || [];
    
    const badges = [];
    for (const badgeId of badgeIds) {
      const badge = await kv.get(`user_badge:${badgeId}`);
      if (badge) {
        badges.push(badge);
      }
    }
    
    return c.json({ badges });
  } catch (error) {
    console.log('Get badges error:', error);
    return c.json({ error: 'Failed to get badges' }, 500);
  }
});

// Notifications
app.post("/make-server-1ec076f3/notifications", async (c) => {
  try {
    const { userId, title, message, type, priority } = await c.req.json();
    const notificationId = `notification_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const notification = {
      id: notificationId,
      userId,
      title,
      message,
      type,
      priority: priority || 'normal',
      timestamp: new Date().toISOString(),
      read: false
    };
    
    await kv.set(`notification:${notificationId}`, notification);
    
    // Add to user's notifications
    const userNotifications = await kv.get(`notifications:${userId}`) || [];
    userNotifications.unshift(notificationId);
    userNotifications = userNotifications.slice(0, 50); // Keep last 50 notifications
    await kv.set(`notifications:${userId}`, userNotifications);
    
    return c.json({ success: true, notificationId });
  } catch (error) {
    console.log('Create notification error:', error);
    return c.json({ error: 'Failed to create notification' }, 500);
  }
});

app.get("/make-server-1ec076f3/notifications/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    const notificationIds = await kv.get(`notifications:${userId}`) || [];
    
    const notifications = [];
    for (const notificationId of notificationIds) {
      const notification = await kv.get(`notification:${notificationId}`);
      if (notification) {
        notifications.push(notification);
      }
    }
    
    return c.json({ notifications });
  } catch (error) {
    console.log('Get notifications error:', error);
    return c.json({ error: 'Failed to get notifications' }, 500);
  }
});

app.put("/make-server-1ec076f3/notifications/:notificationId/read", async (c) => {
  try {
    const notificationId = c.req.param('notificationId');
    const notification = await kv.get(`notification:${notificationId}`);
    
    if (!notification) {
      return c.json({ error: 'Notification not found' }, 404);
    }
    
    notification.read = true;
    notification.readAt = new Date().toISOString();
    await kv.set(`notification:${notificationId}`, notification);
    
    return c.json({ success: true });
  } catch (error) {
    console.log('Mark notification read error:', error);
    return c.json({ error: 'Failed to mark notification as read' }, 500);
  }
});

// Nearby Parks with Air Quality
app.get("/make-server-1ec076f3/parks/:location", async (c) => {
  try {
    const location = c.req.param('location');
    
    // Mock parks data with air quality
    const parks = [
      {
        id: "1",
        name: "Golden Gate Park",
        distance: "0.8 miles",
        aqi: 45,
        aqiCategory: "Good",
        safety: "Safe",
        amenities: ["Playground", "Trails", "Restrooms"],
        coordinates: { lat: 37.7694, lng: -122.4862 }
      },
      {
        id: "2",
        name: "Presidio Park",
        distance: "1.2 miles",
        aqi: 52,
        aqiCategory: "Moderate",
        safety: "Safe",
        amenities: ["Hiking", "Views", "Parking"],
        coordinates: { lat: 37.7989, lng: -122.4662 }
      },
      {
        id: "3",
        name: "Dolores Park",
        distance: "2.1 miles",
        aqi: 38,
        aqiCategory: "Good",
        safety: "Safe",
        amenities: ["Sports", "Views", "Events"],
        coordinates: { lat: 37.7596, lng: -122.4269 }
      }
    ];
    
    return c.json({ parks });
  } catch (error) {
    console.log('Parks data error:', error);
    return c.json({ error: 'Failed to get parks data' }, 500);
  }
});

// Emergency Alerts
app.get("/make-server-1ec076f3/alerts/:location", async (c) => {
  try {
    const location = c.req.param('location');
    
    // Mock emergency alerts
    const alerts = [
      {
        id: "alert_1",
        type: "heat_advisory",
        severity: "moderate",
        title: "Heat Advisory",
        message: "Temperatures expected to reach 95°F today. Stay hydrated and seek shade.",
        timestamp: new Date().toISOString(),
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
        location
      },
      {
        id: "alert_2",
        type: "air_quality",
        severity: "low",
        title: "Air Quality Alert",
        message: "Moderate air quality due to wildfire smoke. Sensitive individuals should limit outdoor activities.",
        timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
        expiresAt: new Date(Date.now() + 12 * 60 * 60 * 1000).toISOString(),
        location
      }
    ];
    
    return c.json({ alerts });
  } catch (error) {
    console.log('Alerts data error:', error);
    return c.json({ error: 'Failed to get alerts' }, 500);
  }
});

// Settings Management
app.post("/make-server-1ec076f3/settings", async (c) => {
  try {
    const { userId, settings } = await c.req.json();
    await kv.set(`settings:${userId}`, settings);
    return c.json({ success: true });
  } catch (error) {
    console.log('Save settings error:', error);
    return c.json({ error: 'Failed to save settings' }, 500);
  }
});

app.get("/make-server-1ec076f3/settings/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    const settings = await kv.get(`settings:${userId}`) || {
      notifications: {
        weatherAlerts: true,
        airQualityAlerts: true,
        healthReminders: true,
        communityUpdates: false
      },
      units: {
        temperature: 'celsius',
        distance: 'metric'
      },
      privacy: {
        shareLocation: true,
        publicProfile: false
      }
    };
    
    return c.json({ settings });
  } catch (error) {
    console.log('Get settings error:', error);
    return c.json({ error: 'Failed to get settings' }, 500);
  }
});

// Analytics endpoint for app usage
app.post("/make-server-1ec076f3/analytics/event", async (c) => {
  try {
    const { userId, event, data } = await c.req.json();
    const eventId = `event_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const analyticsEvent = {
      id: eventId,
      userId,
      event,
      data,
      timestamp: new Date().toISOString()
    };
    
    await kv.set(`analytics:${eventId}`, analyticsEvent);
    
    return c.json({ success: true });
  } catch (error) {
    console.log('Analytics error:', error);
    return c.json({ error: 'Failed to record event' }, 500);
  }
});

Deno.serve(app.fetch);